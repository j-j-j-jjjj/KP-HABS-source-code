from charm.toolbox.pairinggroup import PairingGroup, ZR

def get_coefficients(attr_list, n, group):
    """
    计算多项式系数 y_1, ..., y_n 使得 P(X) = sum y_i * X^{i-1}
    """
    k = len(attr_list)
    if k > n - 1:
        raise ValueError(f"属性个数 {k} 超过了多项式最高次数限制 {n-1}")

    # 初始化长度为 n 的系数列表 (y_1 到 y_n)
    y = [group.init(ZR, 0)] * n
    y[0] = group.init(ZR, 1) # P(X) = 1

    for j in range(k):
        attr = attr_list[j]
        for i in range(j + 1, 0, -1):
            y[i] = y[i] * (-attr) + y[i-1]
        y[0] = y[0] * (-attr)
            
    return y

def verify_batch_test():
    # 1. 初始化 Pairing Group (使用常见的对称配对曲线)
    group = PairingGroup('SS512')
    
    # 2. 设定参数
    n = 10  # 预定义系数总量 (y_1 到 y_{10})
    # 构造一个包含 5 个属性的集合 S (满足 |S| <= n-1)
    S = [group.random(ZR) for _ in range(5)]
    
    print(f"--- 测试开始 ---")
    print(f"目标系数总量 n = {n}")
    print(f"属性集合大小 |S| = {len(S)}")
    
    # 3. 调用函数生成系数
    try:
        y_coeffs = get_coefficients(S, n, group)
        print(f"成功生成 {len(y_coeffs)} 个系数。")
    except Exception as e:
        print(f"生成系数失败: {e}")
        return

    # 4. 验证正确性
    # 逻辑：对于 S 中的每一个 attr，计算 P(attr) = sum_{i=1}^{n} y_i * attr^{i-1}
    print(f"\n正在验证属性是否为多项式的根...")
    all_passed = True
    
    for idx, attr in enumerate(S):
        val = group.init(ZR, 0)
        for i, y in enumerate(y_coeffs):
            # 计算 y_i * (attr ** i)
            term = y * (attr ** i)
            val += term
            
        if val == group.init(ZR, 0):
            print(f"  [OK] 属性 {idx+1} 验证通过：P(attr) = 0")
        else:
            print(f"  [FAILED] 属性 {idx+1} 验证失败：P(attr) = {val}")
            all_passed = False

    # 5. 验证 $y_i = 0$ 对于 $i > |S| + 1$ 的情况
    print(f"\n正在验证高次项补零逻辑...")
    padding_correct = True
    for i in range(len(S) + 1, n):
        if y_coeffs[i] != group.init(ZR, 0):
            padding_correct = False
            print(f"  [ERROR] 系数 y_{i+1} 应为 0，但实际为 {y_coeffs[i]}")
            
    if padding_correct:
        print(f"  [OK] 高次项系数已正确补零。")

    # 6. 最终结果
    if all_passed and padding_correct:
        print(f"\n总结: 测试完全通过！代码符合公式定义。")
    else:
        print(f"\n总结: 测试未通过，请检查代码逻辑。")

# 执行测试
if __name__ == "__main__":
    verify_batch_test()
    group = PairingGroup('SS512')
    S1 = [group.init(ZR, 10), group.init(ZR, 20)]
    S2 = [group.init(ZR, 20), group.init(ZR, 10)] # 顺序相反

    y1 = get_coefficients(S1, 5, group)
    y2 = get_coefficients(S2, 5, group)

    print(y1 == y2) # 结果必为 True