from Setup import Setup
import re

# class lexer:
#     def __init__(self, string: str):
#         # (attr1 and attr2) or (attr3 or (attr4 and attr5))
#         self.text = string
#         self.index = 0

#     # 每调用一次read_token,读取policy中的或一个属性向量或一个连接词或"(" / ")"
#     def read_token(self):
#         while self.index < len(self.text):
#             c = self.text[self.index]
#             if c == '(':
#                 self.index += 1
#                 return '('
#             if c == ')':
#                 self.index += 1
#                 return '('
            
        #     # 读取attrset
        #     if c == '[':
        #         self.index += 1
        #         attrSet = []
        #         f = self.index
        #         while True:
        #             c = self.text[self.index]
        #             if c == ',':
        #                 # print(f'one dimension: {self.text[f: self.index]}')
        #                 attrSet.append(self.text[f: self.index])
        #                 self.index += 1
        #                 f = self.index
        #                 continue
        #             if c == ']':
        #                 # print(f'one dimension: {self.text[f: self.index]}')
        #                 attrSet.append(self.text[f: self.index])
        #                 self.index += 1
        #                 break
        #             self.index += 1
        #             # 切出一个分量
        #             # print(f'one dimension: {self.text[f: self.index]}')
        #             # attr_vector.append(self.text[f: self.index])
        #             # if c == ',' or c == ' ':
        #             #     continue
        #         return attrSet
            
        #     if self.text[self.index: self.index + 3] == 'and':
                
        #         self.index += 3
        #         return 'and'

        #     if self.text[self.index: self.index + 2] == 'or':
        #         self.index += 2
        #         return 'or'

        #     if self.index == len(self.text):
        #         return ""

        #     raise ValueError("bad policy(%s) at %d" % (self.text, self.index))

        # return ""
    
def parseTree(expression: str, pp):
    # 读取并拆分所有"(", ")", "and", "or", attribute
    pattern = r'\(|\)|and|or|[^\s()]+'
    # print(re.findall(pattern, expression))
    expList = re.findall(pattern, expression)
    


if __name__ == "__main__":
    pp, msk = Setup(512, 20, 20, 128)
    print("---------")
    parseTree("(ID_Alice and Role:Manager) or (Dept_Physics or (Level_4 and Key_A))", pp)