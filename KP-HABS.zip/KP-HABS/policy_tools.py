import random
# from Setup import Setup
# from charm.toolbox.pairinggroup import PairingGroup, ZR

def genrate_random_attribute() -> str:
    return bin(random.getrandbits(20))[2:].zfill(20)

def generate_random_attrset(attrNum: int) -> list[str]:
    return [genrate_random_attribute() for _ in range(attrNum)]

# 生成必定满足属性集合的policy
def generate_policy_for_attrset(attrset):
    """
    采用分治法, 需要保证每个括号里面只有两个属性和一个逻辑谓词and
    """
    attrNum = len(attrset)
    if attrNum == 1:
        return attrset[0]
    if attrNum == 2:
        return "(" + attrset[0] + " and " + attrset[1] + ")"
    
    mid = attrNum // 2
    leftPart = generate_policy_for_attrset(attrset[:mid])
    rightPart = generate_policy_for_attrset(attrset[mid:])
    return "(" + leftPart + " and " + rightPart + ")"
    


if __name__ == "__main__":
    # n_a = 20
    # n_m = 128

    # pp, msk = Setup(512, n_a, n_m)
    attrNum = 5
    attrset = generate_random_attrset(attrNum)
    print(attrset)
    policy = generate_policy_for_attrset(attrset)
    print(policy)