"""
此模块主要用于实现各类编码转换函数
"""
from collections import deque
from Setup import Setup
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair
from policy_tools import generate_random_attrset, generate_policy_for_attrset
import re

class TreeNode:
    def __init__(self, left=None, right=None, type=None, attr=None):
        self.left = left    # 左子树
        self.right = right   # 右子树
        self.type = type    # 节点类型: "and", "or", "leaf"
        self.attr = attr  # 如果是leaf类型，有属性
        self.vector = None

def parseTree(expression: str):
    # 读取并拆分所有"(", ")", "and", "or", attribute
    pattern = r'\(|\)|and|or|[^\s()]+'
    # print(re.findall(pattern, expression))
    expList = re.findall(pattern, expression)
    # 构建布尔树
    rootNode = constructTree(expList)
    # printTree(rootNode=rootNode)
    return rootNode

def constructTree(expList: list):
    # print(expList)
    if not expList:
        return None

    # 获取并移除第一个 token
    token = expList.pop(0)

    if token == '(':
        # 1. 递归解析左子树
        left_node = constructTree(expList)
        
        # 2. 此时列表头部应该是操作符 (and/or)
        op_type = expList.pop(0)
        
        # 3. 递归解析右子树
        right_node = constructTree(expList)
        
        # 4. 移除对应的右括号 ')'
        if expList and expList[0] == ')':
            expList.pop(0)
            
        return TreeNode(left=left_node, right=right_node, type=op_type)
    
    else:
        # 叶子节点情况：token 直接就是属性字符串
        return TreeNode(type="leaf", attr=token)

# 遍历打印布尔树
def print_tree(node, level=0, prefix="Root: "):
    if not node: return
    indent = "    " * level
    if node.type == "leaf":
        print(f"{indent}{prefix}[Leaf] {node.attr}")
    else:
        print(f"{indent}{prefix}[{node.type.upper()}]")
        print_tree(node.left, level + 1, "L-- ")
        print_tree(node.right, level + 1, "R-- ")

# 将布尔树编码为lsss矩阵
def parseMatrix(rootNode: TreeNode):
    # 对于此lsss矩阵，第一列是各行对应的属性，其余列才是编码后的向量
    lsssMatrix = []
    if not rootNode:
        return
    counter = 1
    rootNode.vector = [1]
    nodeQueue = deque([rootNode])
    # 采取广度优先搜索
    while len(nodeQueue) > 0:
        curNode = nodeQueue.popleft()
        # print(curNode.type)
        # 如果当前节点是or类型，将它的两个子结点的向量标注为与它相同，并保持counter不变
        if curNode.type == "or":
            curNode.left.vector = curNode.vector[::]
            curNode.right.vector = curNode.vector[::]
        # 当前节点是and类型
        elif curNode.type == "and":
            while counter - len(curNode.vector) > 0:
                curNode.vector.append(0)
            curNode.left.vector = [0 for _ in range(counter)]
            curNode.left.vector.append(-1)
            curNode.right.vector = curNode.vector[::]
            curNode.right.vector.append(1)
            counter = counter + 1
        # 当前节点是leaf类型
        else:
            # 将该节点的向量加入lsss矩阵
            lsssMatrix.append([curNode.attr] + curNode.vector)
        if curNode.type != "leaf":
            nodeQueue.append(curNode.left)
            nodeQueue.append(curNode.right)
    # 对lsss矩阵中长度不足的补0
    for eachRow in lsssMatrix:
        while counter + 1 - len(eachRow) > 0:
                eachRow.append(0)
    return lsssMatrix





if __name__ == '__main__':
    pp, msk = Setup(512, 500, 5, 100)
    n_a, n_l, n_m, group, g, Y, A_list, U_list, M_list = pp

    attrset = generate_random_attrset(n_a, 5)
    expression = generate_policy_for_attrset(attrset)
    # print(attrset)
    # print(expression)

    rootnode = parseTree(expression)
    # print(parseMatrix(rootNode=rootnode))
    lsssMatrix = parseMatrix(rootNode=rootnode)
    # for row in lsssMatrix:
    #     print(row[1:])
    lsss_set = []
    for element in lsssMatrix:
        lsss_set.append(element[0])
    # parsed_set = parseAttrset(attrset, pp)
    counter = 0