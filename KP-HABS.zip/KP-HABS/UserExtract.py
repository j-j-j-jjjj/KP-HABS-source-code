# import numpy as np
import random
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, pair
from math import prod
from Setup import Setup, H_ID
from policy_tools import generate_random_attrset, generate_policy_for_attrset
from parser import parseTree, parseMatrix
from LSSS import lsssShare, lsssRecon, lsssCheck
from AuthKeyGen import AuthExtract, AuthDelegate
from coefficients import get_coefficients

def UserExtract(pp, ASK, ID, lsssMatrix):
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp
    group: PairingGroup
    ASK0, ASK1, Ri_list = ASK
    l = len(lsssMatrix)
    # 去掉表示映射到属性的第一列
    n = len(lsssMatrix[0]) - 1 
    # r_2, ..., r_n
    r_list = list(group.random(ZR, n - 1))

    Hid = H_ID(ID, U_list)
    uski_list = []
    overline_r_i = group.random(ZR, l)
    for i in range(l):
        # overline_r_i = group.random(ZR)
        usk_i_0 = (g ** sum([lsssMatrix[i][j] * r_list[j - 2] for j in range(2, n + 1)])) * (ASK0 ** lsssMatrix[i][1]) * ((Hid * A0 * Ai_list[int(lsssMatrix[i][0])])) ** overline_r_i[i]
        usk_i_1 = g ** overline_r_i[i]
        usk_i_2 = ASK1 ** lsssMatrix[i][1]
        usk_i_3 = []
        for j in range(len(Ai_list)):
            if j != int(lsssMatrix[i][0]):
                usk_i_3.append(Ai_list[j] ** overline_r_i[i])
        # usk_i_3 = [(A_list[1] ** (-group.hash(lsssMatrix[i][0], ZR) ** (j + 1))) * A_list[j + 2] for j in range(n_a - 1)]
        uski_list.append((usk_i_0, usk_i_1, usk_i_2, usk_i_3))

        # y_list = get_coefficients([group.hash(lsssMatrix[i][0], ZR) for i in range(l)], n_a, group)
        # test3 = prod([((A_list[1] ** (-group.hash(lsssMatrix[i][0], ZR) ** (j + 1))) * A_list[j + 2]) ** y_list[j + 1] for j in range(n_a - 1)])
        # test3 *= A_list[0]
        # print(test3 == A_list[0] * prod([A_list[k + 1] ** y_list[k] for k in range(n_a)]))

        # test_sigma_4_left = []

    # y_list = get_coefficients([group.hash(lsssMatrix[i][0], ZR) for i in range(l)], n_a, group)
    # for i in range(l):
    #     test_sigma_4_left_i = A_list[0] ** overline_r_i[i]
    #     for j in range(n_a - 1):
    #         test_sigma_4_left_i *= uski_list[i][3][j] ** (y_list[j + 1])
    #     print(test_sigma_4_left_i == (A_list[0] * prod([A_list[k + 1] ** y_list[k] for k in range(n_a)])) ** overline_r_i[i])
    return (uski_list, Hid, overline_r_i)


if __name__ == "__main__":
    n_a = 20
    n_m = 128
    pp, msk = Setup(512, n_a, n_m)
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp

    h = 3
    ID_pre = list(group.random(ZR, h))
    ASK_pre = AuthExtract(pp, msk, ID_pre)
    id_next = group.random(ZR)
    ASK = AuthDelegate(pp, ASK_pre, ID_pre, id_next)
    ID = ID_pre + [id_next]

    attrNum = 10
    attrset_index = random.sample(range(50), attrNum)
    for i in range(len(attrset_index)):
        attrset_index[i] = str(attrset_index[i])
    # attrset = [universe[attrset_index[i]] for i in range(attrNum)]
    policy = generate_policy_for_attrset(attrset_index)
    rootNode = parseTree(policy)
    lsssMatrix = parseMatrix(rootNode)
    # print(attrset_index)
    print([lsssMatrix[i][0] for i in range(len(lsssMatrix))])

    UserExtract(pp, ASK, ID, lsssMatrix)
    