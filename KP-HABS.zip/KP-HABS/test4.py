import re

class ExpressionParser:
    def __init__(self, expression):
        # 1. 定义保留字：( , ) , and, or
        # 2. 定义属性：匹配任何非空格且不是保留字的字符
        # 正则逻辑：先匹配保留字，如果不匹配，则匹配连续的非空且不属于保留字符合的字符
        pattern = r'\(|\)|and|or|[^\s()]+'
        
        # 预先提取所有 tokens
        self.tokens = re.findall(pattern, expression)
        self.cursor = 0

    def next_token(self):
        """
        每次调用返回下一个元素：括号、谓词或任意属性字符串
        """
        if self.cursor < len(self.tokens): # len() 是 O(1) 操作
            token = self.tokens[self.cursor]
            self.cursor += 1
            # 过滤掉单独匹配出来的 'and' 'or' 作为属性的情况（正则已处理，此处为保险）
            return token
        return None

# --- 测试代码 ---
# 这里的属性可以是 ID_Alice, Role:Manager, 或者 12345
expr = "(ID_Alice and Role:Manager) or (Dept_Physics or (Level_4 and Key_A))"
parser = ExpressionParser(expr)

token = parser.next_token()
while token:
    print(f"读取到: {token}")
    token = parser.next_token()