from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, pair
import hashlib
from policy_tools import generate_random_attrset

def Setup(secParam: int, n_a: int, n_m: int):
    group = PairingGroup('SS512', secparam=secParam)
    g = group.random(G1)
    alpha = group.random(ZR)
    Y = pair(g, g) ** alpha

    # A_list = group.random(G1, n_a + 1)
    A0 = group.random(G1)
    Ai_list = group.random(G1, 50)
    universe = generate_random_attrset(50)

    U_list = group.random(G1, n_a + 1)
    M_list = group.random(G1, n_m + 1)

    pp = (n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list)
    msk = alpha
    return pp, msk

def H_ID(ID_vector, U_list):
    n_ID = len(ID_vector)
    HID = U_list[0]
    for i in range(n_ID):
        HID *= U_list[i + 1] ** ID_vector[i]
    return HID

# def H_attr(attr: str, A_list: list):
#     n_a = len(attr)
#     Hattr = A_list[0]
#     for i in range(n_a):
#         if attr[i] == "1":
#             Hattr *= A_list[i]
#     return Hattr

def H_m(m: str, M_list: list):
    n_m = len(m)
    Hm = M_list[0]
    for i in range(n_m):
        if m[i] == "1":
            Hm *= M_list[i]
    return Hm


# 转为原始 01 串
def to_01_str(data):
    """
    展开数据到 01 字符串
    """
    if isinstance(data, (str, int)):
        if isinstance(data, str):
            data = data.encode('utf-8')
        else:
            # 处理整数
            data = data.to_bytes((data.bit_length() + 7) // 8, 'big')
            
    # 每个字节严格转为 8 位 01 字符串
    return ''.join(f'{b:08b}' for b in data)

def universal_hash(message, n_m=128):
    """
    利用 SHA-256 生成指定长度的 01 字符串
    """
    # SHA-256 的均匀性足以满足 Universal 的安全证明要求
    h_digest = hashlib.sha256(str(message).encode()).digest()
    
    # 将哈希结果转为 01 字符串
    full_01_string = to_01_str(h_digest)
    
    # 截取前 n_m 位 (例如 128 位)
    return full_01_string[:n_m]
        

    

if __name__ == "__main__":
    n_a = 10
    n_m = 128

    pp, msk = Setup(512, n_a, n_m)
    print(universal_hash("Hello World"))
