from Setup import Setup, H_ID
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, pair
from math import prod

def AuthExtract(pp, msk, ID):
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp
    alpha = msk
    h = len(ID)

    r_auth = group.random(ZR)
    ASK0 = (g ** alpha) * (H_ID(ID, U_list) ** r_auth)
    ASK1 = g ** r_auth
    Ri_list = [U_list[i] ** r_auth for i in range(h + 1, n_a + 1)]
    return (ASK0, ASK1, Ri_list) 

def AuthDelegate(pp, ASK_pre, ID_pre, id):
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp
    ASK0_pre, ASK1_pre, Ri_list_pre = ASK_pre
    r_auth_next = group.random(ZR)
    ASK0_next_left = ASK0_pre * (Ri_list_pre[0] ** id)
    h_pre = len(ID_pre)
    ASK0_next_right = (U_list[0] * prod([U_list[i] ** ID_pre[i - 1] for i in range(1, h_pre + 1)]) * (U_list[h_pre + 1] ** id)) ** r_auth_next
    ASK0_next = ASK0_next_left * ASK0_next_right

    # ID_next = ID_pre + [id]
    # print(f'test for AuthDelegate: {ASK0_next == (g ** msk) * (H_ID(ID_next, U_list) ** (r_auth_next + r_auth))}')
    # print(g)

    ASK1_next = ASK1_pre * (g ** r_auth_next)

    Ri_list_next = [Ri_list_pre[i] * (U_list[i + h_pre + 1] ** r_auth_next) for i in range(1, len(Ri_list_pre))]
    ASK_next = (ASK0_next, ASK1_next, Ri_list_next)
    return ASK_next


if __name__ == "__main__":
    h = 3
    pp, msk = Setup(512, 20, 128)
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp

    ID = list(group.random(ZR, h))
    ASK = AuthExtract(pp, msk, ID)

    id_next = group.random(ZR)

    ASK_next = AuthDelegate(pp, ASK, ID, id_next)
