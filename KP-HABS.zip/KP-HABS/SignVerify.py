# import numpy as np
import random
import time
from math import prod
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, pair
import pickle
from Setup import Setup, H_ID, universal_hash, H_m
from policy_tools import generate_random_attrset, generate_policy_for_attrset
from parser import parseTree, parseMatrix
from LSSS import lsssShare, lsssRecon, lsssCheck, G_INT_EXP
from AuthKeyGen import AuthExtract, AuthDelegate
from UserExtract import UserExtract
from coefficients import get_coefficients

def Sign(pp, usk, lsssMatrix, message, attrset):
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp
    group: PairingGroup
    uski_list, Hid, overline_r_i = usk
    attrNum = len(attrset)

    beta, gamma, chi = group.random(ZR, 3)
    sigma_1 = g ** beta

    omega_vector = lsssRecon(attrset, lsssMatrix)
    # ** / G_INT_EXP
    sigma_2 = (g ** gamma) * prod([G_INT_EXP(uski_list[i][1], omega_vector[i]) for i in range(attrNum)])
    m = universal_hash((sigma_2, message, attrset), n_m)

    sigma_3 = (g ** chi) * prod([G_INT_EXP(uski_list[i][1] * uski_list[i][2], omega_vector[i]) for i in range(attrNum)])

    # y_list = get_coefficients(attrset_hash, n_a, group)
    sigma_4_left = []
    for i in range(attrNum):
        sigma_4_left_i = uski_list[i][0]
        sigma_4_left_i *= prod(uski_list[i][3])
        sigma_4_left.append(G_INT_EXP(sigma_4_left_i, omega_vector[i]))
    sigma_4 = prod(sigma_4_left) * ((A0 * prod(Ai_list)) ** gamma) * (H_m(m, M_list) ** beta) * (Hid ** chi)

    # test_sigma_4_left = []
    # for i in range(attrNum):
    #     test_sigma_4_left_i = A_list[0] ** overline_r_i[i]
    #     for j in range(n_a - 1):
    #         test_sigma_4_left_i *= uski_list[i][3][j] ** y_list[j + 1]
    #     print(test_sigma_4_left_i == (A_list[0] * prod([A_list[k + 1] ** y_list[k] for k in range(n_a)])) ** overline_r_i[i])

    # test_sigma_4 = prod(test_sigma_4_left) * (A_list[0] * prod([A_list[k + 1] ** y_list[k] for k in range(n_a)]) ** gamma)
    # print(pair(test_sigma_4, g) == pair(sigma_2, A_list[0] * prod([A_list[k + 1] ** y_list[k] for k in range(n_a)])))

    return (sigma_1, sigma_2, sigma_3, sigma_4)
    # sigma_4 = prod([uski_list[i][0] for i in range(len(attrset))])

def Verify(pp, message, ID, attrset_index, sigma):
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp
    sigma_1, sigma_2, sigma_3, sigma_4 = sigma
    attrNum = len(attrset_index)

    m = universal_hash((sigma_2, message, attrset_index), n_m)
    # y_list = get_coefficients(attrset_hash, n_a, group)
    eq_left = pair(sigma_4, g)
    eq_right = Y * pair(H_m(m, M_list), sigma_1) * pair(sigma_2, A0 * prod(Ai_list)) * pair(sigma_3, H_ID(ID, U_list))
    return eq_left == eq_right

def benchmark(n_a, n_m, depth, attrNum):
    pp, msk = Setup(512, n_a, n_m)
    n_a, n_m, group, g, Y, A0, Ai_list, universe, U_list, M_list = pp
    group: PairingGroup
    if depth > 2:
        ID_pre = list(group.random(ZR, depth - 1))
    else:
        ID_pre = [group.random(ZR)]
    ASK_pre = AuthExtract(pp, msk, ID_pre)
    id_next = group.random(ZR) 
    
    ASK = AuthDelegate(pp, ASK_pre, ID_pre, id_next)
    
    ID = ID_pre + [id_next]

    attrset_index = random.sample(range(50), attrNum)
    for i in range(len(attrset_index)):
        attrset_index[i] = str(attrset_index[i])
    # attrset_hash = [group.hash(attr, ZR) for attr in attrset]
    policy = generate_policy_for_attrset(attrset_index)
    rootNode = parseTree(policy)
    lsssMatrix = parseMatrix(rootNode)

    usk = UserExtract(pp, ASK, ID, lsssMatrix)

    # 固定参数情况下运行10次的时间统计
    single_sign_time = 0.0
    single_verify_time = 0.0
    for i in range(10):
        message = "Hello World"

        sign_start_time = time.perf_counter()
        sigma = Sign(pp, usk, lsssMatrix, message, attrset_index)
        sign_end_time = time.perf_counter()
        single_sign_time += sign_end_time - sign_start_time

        # if i == 0:
        #     print('***************************')
        #     print(f'depth = {depth}, attrNum = {attrNum}, signature bytes = {get_signature_bytes(sigma, group)}')
        #     print('***************************')

        verify_start_time = time.perf_counter()
        Verify(pp, message, ID, attrset_index, sigma)
        verify_end_time = time.perf_counter()
        single_verify_time += verify_end_time - verify_start_time
        # print(result)
    return single_sign_time / 10, single_verify_time / 10

def get_signature_bytes(signature, group):
    def serialize_recursive(item):
        if isinstance(item, (list, tuple)):
            # 递归处理元组或列表中的每个元素
            return b"".join(serialize_recursive(i) for i in item)
        elif isinstance(item, dict):
            # 递归处理字典的值
            return b"".join(serialize_recursive(v) for v in item.values())
        elif hasattr(item, 'type') or 'Element' in str(type(item)):
            # 识别并处理 Charm-Crypto 的群元素
            return group.serialize(item)
        else:
            # 处理普通的 Python 数据类型 (如 int, str)
            return pickle.dumps(item)

    # 获取所有组件序列化后的总字节流
    full_bytes = serialize_recursive(signature)
    return len(full_bytes)

if __name__ == "__main__":
    # benchmark(50, 128, 3, 10)
    for i in range(1, 6):
        avg_sign_time, avg_verify_time = benchmark(50, 128, 3, i * 10)
        print(f'depth = 3, attrNum = {i * 10}, sign: {avg_sign_time}; verify: {avg_verify_time}')

    for i in range(1, 6):
        avg_sign_time, avg_verify_time = benchmark(50, 128, i * 2, 10)
        print(f'depth = {i * 2}, attrNum = 10, sign: {avg_sign_time}; verify: {avg_verify_time}')

    
        