from charm.toolbox.pairinggroup import PairingGroup, G1

group = PairingGroup("SS512", secparam = 512)

data = [group.random(G1), (group.random(G1), group.random(G1), {'a': group.random(G1)})]
h = group.hash(data, G1)  # h 是 G1 上的元素

print(type(h))       # <class 'charm.core.math.pairing.Element'>
print(group.ismember(h))  # True，验证它确实是 G1 元素
