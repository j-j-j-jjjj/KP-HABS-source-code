from DS_TS import SIG_Setup, TOS_Key, TOS_Tag, TOS_Sign, Unbound_TOS_Sign
import PKE
from policy_tools import generate_attrTag

def Key_gen(gk, k, n, depth):
    group, G, C, F, U = gk
    pk_TA, sk_TA = PKE.KeyGen(group, n)
    pkd_list = []
    skd_list = []
    for i in range(depth):
        curr_pk, curr_sk = TOS_Key(gk, k)
        pkd_list.append(curr_pk)
        skd_list.append(curr_sk)
    upk, usk = TOS_Key(gk, k)
    return pk_TA, sk_TA, pkd_list, skd_list, upk, usk

def AttIssue(attr_set, gk, k, pkd_list, skd_list, upk):
    attrNum = len(attr_set)
    depth = len(pkd_list)
    user_warr = {}
    for i in range(attrNum):
        user_warr[attr_set[i]] = (pkd_list + [upk], [])
    for i in range(attrNum):
        for j in range(depth):
            curr_msg_list = []
            # RA issue att to IA, or IA issue att to IA
            if j < depth - 1:
                for l in range(j + 1):
                    curr_msg_list += list(pkd_list[l][:5]) + pkd_list[l][5] + pkd_list[l][6]
                curr_sigma_att = Unbound_TOS_Sign(gk, pkd_list[j], skd_list[j], attr_set[i], curr_msg_list, k)
            # IA issue att to user
            else:
                for l in range(depth + 1):
                    if l < depth:
                        curr_msg_list += list(pkd_list[l][:5]) + pkd_list[l][5] + pkd_list[l][6]
                    else:
                        curr_msg_list += list(upk[:5]) + upk[5] + upk[6]
                curr_sigma_att = Unbound_TOS_Sign(gk, pkd_list[j], skd_list[j], attr_set[i], curr_msg_list, k)
            user_warr[attr_set[i]][1].append(curr_sigma_att)
    return user_warr



if __name__ == '__main__':
    gk = SIG_Setup(512)
    group, G, C, F, U = gk
    k = 7
    n = 200
    depth = 3 # 1 RA and 2 IA and 1 user
    attrNum = 2
    pk_TA, sk_TA, pkd_list, skd_list, upk, usk = Key_gen(gk, k, n, depth)
    attr_set = generate_attrTag(gk, attrNum)
    user_warr = AttIssue(attr_set, gk, k, pkd_list, skd_list, upk)
