import numpy as np
from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair
from Groth_Sahai import GS

def KeyGen(group, n):
    g1, g2, g3 = group.random(G1, 3)

    alpha_list = [group.random(ZR, 3) for _ in range(n)]
    h1i_list = [(g1 ** alpha_list[i][0]) * (g3 ** alpha_list[i][2]) for i in range(n)]
    h2i_list = [(g2 ** alpha_list[i][1]) * (g3 ** alpha_list[i][2]) for i in range(n)]

    beta_list = [group.random(ZR, 3) for _ in range(n + 5)]
    fi1_list = [(g1 ** beta_list[i][0]) * (g3 ** beta_list[i][2]) for i in range(n + 5)]
    fi2_list = [(g2 ** beta_list[i][1]) * (g3 ** beta_list[i][2]) for i in range(n + 5)]

    pk = (g1, g2, g3, h1i_list, h2i_list, fi1_list, fi2_list)
    sk = (alpha_list, beta_list)

    return pk, sk

def Enc(group, g, pk, L, m):
    r, s = group.random(ZR, 2)
    g1, g2, g3, h1i_list, h2i_list, fi1_list, fi2_list = pk
    n = len(m)
    ui_list = [g, g1 ** r, g2 ** s, g3 ** (r + s)]
    ci_list = [m[i] * (h1i_list[i] ** r) * (h2i_list[i] ** s) for i in range(n)]

    v = pair((fi1_list[n + 4] ** r) * (fi2_list[n + 4] ** s), L)
    for i in range(4):
        v *= pair((fi1_list[i] ** r) * (fi2_list[i] ** s), ui_list[i])
    for i in range(4, n + 4):
        v *= pair((fi1_list[i] ** r) * (fi2_list[i] ** s), ci_list[i - 4])
    
    return (ui_list[1], ui_list[2], ui_list[3], ci_list, v), (r, s)

def generate_valid_cipher_proof(pk, ciphertext, randomness, msg, pp, crs, td, GS_cipher: GS):
    g1, g2, g3, h1i_list, h2i_list, fi1_list, fi2_list = pk
    u1, u2, u3, ci_list, v = ciphertext
    r, s = randomness
    n = len(ci_list)
    cipher_pi_list = []

    cipher_x_u1 = [u1, g1 ** r]
    cipher_y_u1 = [pp['G2'], pp['G2']]
    gammaT_u1 = [[1, 0], [0, -1]]
    cipher_c_a_u1 = [1, 1]
    cipher_c_b_u1 = [1, 1]
    com_cipher_x_u1, com_cipher_y_u1, r_u1, s_u1 = GS_cipher.commit(crs, cipher_x_u1, cipher_y_u1, cipher_c_a_u1, cipher_c_b_u1)
    cipher_proof_u1 = GS_cipher.prove(crs, cipher_x_u1, cipher_y_u1, r_u1, s_u1, com_cipher_y_u1, [gammaT_u1])
    # print(GS_cipher.verify(pp, crs, cipher_proof_u1, com_cipher_x_u1, com_cipher_y_u1, [gammaT_u1]))
    cipher_pi_list.append((cipher_proof_u1, com_cipher_x_u1, com_cipher_y_u1, [gammaT_u1]))

    cipher_x_u2 = [u2, g2 ** s]
    cipher_y_u2 = cipher_y_u1
    gammaT_u2 = gammaT_u1
    cipher_c_a_u2 = [1, 1]
    cipher_c_b_u2 = [1, 1]
    com_cipher_x_u2, com_cipher_y_u2, r_u2, s_u2 = GS_cipher.commit(crs, cipher_x_u2, cipher_y_u2, cipher_c_a_u2, cipher_c_b_u2)
    cipher_proof_u2 = GS_cipher.prove(crs, cipher_x_u2, cipher_y_u2, r_u2, s_u2, com_cipher_y_u2, [gammaT_u2])
    # print(GS_cipher.verify(pp, crs, cipher_proof_u2, com_cipher_x_u2, com_cipher_y_u2, [gammaT_u2]))
    cipher_pi_list.append((cipher_proof_u2, com_cipher_x_u2, com_cipher_y_u2, [gammaT_u2]))

    cipher_x_u3 = [u3, g3 ** (r + s)]
    cipher_y_u3 = cipher_y_u1
    gammaT_u3 = gammaT_u1
    cipher_c_a_u3 = [1, 1]
    cipher_c_b_u3 = [1, 1]
    com_cipher_x_u3, com_cipher_y_u3, r_u3, s_u3 = GS_cipher.commit(crs, cipher_x_u3, cipher_y_u3, cipher_c_a_u3, cipher_c_b_u3)
    cipher_proof_u3 = GS_cipher.prove(crs, cipher_x_u3, cipher_y_u3, r_u3, s_u3, com_cipher_y_u3, [gammaT_u3])
    # print(GS_cipher.verify(pp, crs, cipher_proof_u3, com_cipher_x_u3, com_cipher_y_u3, [gammaT_u3]))
    cipher_pi_list.append((cipher_proof_u3, com_cipher_x_u3, com_cipher_y_u3, [gammaT_u3]))

    gammaT_ci = np.eye(n, dtype=int)
    gammaT_ci[0][0] = -1
    gammaT_ci = gammaT_ci.tolist()
    for i in range(n):
        curr_x = [ci_list[i], msg[i], h1i_list[i] ** r, h2i_list[i] ** s]
        curr_y = [pp['G2'] for _  in range(4)]
        curr_c_a = [1, None, 1, 1]
        curr_c_b = [1, 1, 1, 1]

        curr_com_x, curr_com_y, curr_r, curr_s = GS_cipher.commit(crs, curr_x, curr_y, curr_c_a, curr_c_b)
        curr_proof = GS_cipher.prove(crs, curr_x, curr_y, curr_r, curr_s, curr_com_y, [gammaT_ci])
        # print(GS_cipher.verify(pp,crs, curr_proof, curr_com_x, curr_com_y, [gammaT_ci]))
        cipher_pi_list.append((curr_proof, curr_com_x, curr_com_y, [gammaT_ci]))
    return cipher_pi_list

def verify_valid_cipher_proof(pp, crs, GS_cipher: GS, cipher_pi_list):
    for each_pi in cipher_pi_list:
        curr_proof, curr_com_x, curr_com_y, curr_GammaT = each_pi
        if not GS_cipher.verify(pp, crs, curr_proof, curr_com_x, curr_com_y, curr_GammaT): 
            return False
    return True

def Dec(g, sk, L, cipher):
    u1, u2, u3, ci_list, v = cipher
    ui_list = [g, u1, u2, u3]
    alpha_list, beta_list = sk
    n = len(ci_list)

    test_v = pair((u1 ** beta_list[n + 4][0]) * (u2 ** beta_list[n + 4][1]) * (u3 ** beta_list[n + 4][2]), L)
    for i in range(4):
        test_v *= pair((u1 ** beta_list[i][0]) * (u2 ** beta_list[i][1]) * (u3 ** beta_list[i][2]), ui_list[i])
    for i in range(4, n + 4):
        test_v *= pair((u1 ** beta_list[i][0]) * (u2 ** beta_list[i][1]) * (u3 ** beta_list[i][2]), ci_list[i - 4])
    
    if test_v != v:
        print('invalid ciphertext')
        return None
    
    m = []
    for i in range(n):
        m.append(ci_list[i] * (((u1 ** alpha_list[i][0]) * (u2 ** alpha_list[i][1]) * (u3 ** alpha_list[i][2])) ** -1))

    return m



    

if __name__ == '__main__':
    group = PairingGroup("SS512", secparam = 512)
    g = group.random(G1)
    message_len = 16
    pk, sk = KeyGen(group, message_len)
    L = group.random(G1)
    m_vector = [group.random(G1) for _ in range(message_len - 2)]
    cipher, randomness = Enc(group, g, pk, L, m_vector)
    dec_m = Dec(g, sk, L, cipher)

    GS_g1, GS_g2 = group.random(G1, 2)
    pp={'G1':GS_g1,'G2':GS_g2,'GT':pair(GS_g1,GS_g2)} 
    GS_test = GS(group)
    crs, td = GS_test.Transpatent_Setup(pp)
    cipher_pi_list = generate_valid_cipher_proof(pk, cipher, randomness, m_vector, pp, crs, td, GS_test)
    print(verify_valid_cipher_proof(pp, crs, GS_test, cipher_pi_list))