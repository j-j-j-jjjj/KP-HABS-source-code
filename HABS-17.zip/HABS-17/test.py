def list_tuple_flatten(list_tuple):
    flatten_list = []
    # print(list_tuple)
    for element in list_tuple:
        if isinstance(element, list) or isinstance(element, tuple):
            flatten_list += list_tuple_flatten(element)
        else:
            flatten_list.append(element)
    return flatten_list

if __name__ == '__main__':
    input1 = [1, 2, (3, [()]), 'A', ['B', (12, [()])]]
    print(list_tuple_flatten(input1))