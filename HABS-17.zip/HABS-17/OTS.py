from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair

def OTS_Setup(group: PairingGroup):
    OTS_g1, OTS_g2 = group.random(G1, 2)
    zeta = pair(OTS_g1, OTS_g2)
    return ((OTS_g1, OTS_g2, group), zeta)

def OTS_KGen(pp):
    G, zeta = pp
    OTS_g1, OTS_g2, group = G
    k1, k2, k3 = group.random(ZR, 3)
    K1 = OTS_g2 ** k1
    K2 = OTS_g2 ** k2
    sk = (k1, k2, k3)
    pk = (K1, K2)
    return pk, sk

def OTS_Sign(pp, sk, m):
    G, zeta = pp
    OTS_g1, OTS_g2, group = G
    k1, k2, k3 = sk

    r = group.random(ZR)
    sigma = OTS_g1 ** ((k1 + m + k2 * r) ** -1)
    return (sigma, r)

def OTS_Verify(pp, pk, signature, m):
    G, zeta = pp
    OTS_g1, OTS_g2, group = G
    K1, K2 = pk
    sigma, r = signature
    return pair(sigma, K1 * (OTS_g2 ** m) * (K2 ** r)) == zeta

if __name__ == '__main__':
    group = PairingGroup("SS512", secparam = 512)
    pp = OTS_Setup(group)
    pk, sk = OTS_KGen(pp)
    m = group.random(ZR)
    signature = OTS_Sign(pp, sk, m)
    print(OTS_Verify(pp, pk, signature, m))