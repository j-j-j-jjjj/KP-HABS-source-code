import math
import numpy as np
from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair
from Groth_Sahai import GS

def SIG_Setup(secParam: int):
    group = PairingGroup("SS512", secparam = secParam)
    G, C, F, U = group.random(G1, 4)
    return (group, G, C, F, U)

def TOS_Key(gk, k):
    group, G, C, F, U = gk
    w_z, w_r, miu_z, miu_s, tao = group.random(ZR, 5)
    G_z = G ** w_z
    G_r = G ** w_r
    H_z = G ** miu_z
    H_s = G ** miu_s
    G_t = G ** tao

    chi_list = [group.random(ZR) for _ in range(k)]
    gammai_list = [group.random(ZR) for _ in range(k)]
    deltai_list = [group.random(ZR) for _ in range(k)]

    Gi_list = [(G_z ** chi_list[i]) * (G_r ** gammai_list[i]) for i in range(k)]
    Hi_list = [(H_z ** chi_list[i]) * (H_s ** deltai_list[i]) for i in range(k)]

    pk = (G_z, G_r, H_z, H_s, G_t, Gi_list, Hi_list)
    sk = (w_r, miu_s, tao, chi_list, gammai_list, deltai_list)

    return pk, sk

def TOS_Tag(gk):
    group, G, C, F, U = gk
    t = group.random(ZR)
    return (C ** t, F ** t, U ** t)

def TOS_Sign(gk, pk, sk, msg, tag):
    group, G, C, F, U = gk
    G_z, G_r, H_z, H_s, G_t, Gi_list, Hi_list = pk
    w_r, miu_s, tao, chi_list, gammai_list, deltai_list = sk
    T, T_1, T_2 = tag

    zeta = group.random(ZR)

    Z_tilde = G ** zeta
    k = len(msg)
    for i in range(k):
        Z_tilde *= msg[i] ** (-1 * chi_list[i])
    R_tilde = ((T ** tao) * (G_z ** (-1 * zeta))) ** (w_r ** -1)
    for i in range(k):
        R_tilde *= msg[i] ** (-1 * gammai_list[i])
    S = (H_z ** (-1 * zeta)) ** (miu_s ** -1)
    for i in range(k):
        S *= msg[i] ** (-1 * deltai_list[i])

    pow_msg_chi = group.init(G1, 1)
    pow_msg_delta = group.init(G1, 1)
    for i in range(k):
        pow_msg_chi *= msg[i] ** (-1 * chi_list[i])
        pow_msg_delta *= msg[i] ** (-1 * deltai_list[i])
    return (Z_tilde, R_tilde, S)

def TOS_Verify(gk, pk, tag, msg, sigma):
    group, G, C, F, U = gk
    G_z, G_r, H_z, H_s, G_t, Gi_list, Hi_list = pk
    T, T_1, T_2 = tag
    Z_tilde, R_tilde, S = sigma

    k = len(msg)

    eq_1_right = pair(G_z, Z_tilde) * pair(G_r, R_tilde)
    for i in range(k):
        eq_1_right *= pair(Gi_list[i], msg[i])
    if pair(T, G_t) != eq_1_right:
        print('TOS Verify, eq1 failed')
        return False
    
    eq_2_right = pair(H_z, Z_tilde) * pair(H_s, S)
    for i in range(k):
        eq_2_right *= pair(Hi_list[i], msg[i])
    if group.init(GT, 1) != eq_2_right:
        print('TOS Verify, eq2 failed')
        return False
    
    return True

def generate_TOS_proof(gk, pk, tag, msg, sigma, pp, GS_TOS: GS, crs, td):
    group, G, C, F, U = gk
    G_z, G_r, H_z, H_s, G_t, Gi_list, Hi_list = pk
    T, T_1, T_2 = tag
    Z_tilde, R_tilde, S = sigma
    k = len(msg)

    TOS_x1 = [G_z, G_r]
    TOS_y1 = [Z_tilde, R_tilde]
    for i in range(k):
        TOS_x1.append(Gi_list[i])
        TOS_y1.append(msg[i])
    TOS_x1.append(T)
    TOS_y1.append(G_t)
    gammaT_1 = np.eye(k + 3, dtype=int)
    gammaT_1[k + 2][k + 2] = -1
    gammaT_1 = gammaT_1.tolist()
    TOS_c_a1 = [1 for _ in range(k + 3)]
    TOS_c_b1 = [None, None, None] + [1 for _ in range(k)]

    com_TOS_x1, com_TOS_y1, tr1, ts1 = GS_TOS.commit(crs, TOS_x1, TOS_y1, TOS_c_a1, TOS_c_b1)
    TOS_proof1 = GS_TOS.prove(crs, TOS_x1, TOS_y1, tr1, ts1, com_TOS_y1, [gammaT_1])
    # print(GS_TOS.verify(pp, crs, TOS_proof1, com_TOS_x1, com_TOS_y1, [gammaT_1]))

    TOS_x2 = [H_z, H_s]
    TOS_y2 = [Z_tilde, S]
    for i in range(k):
        TOS_x2.append(Hi_list[i])
        TOS_y2.append(msg[i])
    gammaT_2 = np.eye(k + 2, dtype=int)
    gammaT_2 = gammaT_2.tolist()
    TOS_c_a2 = [None for _ in range(k + 2)]
    TOS_c_b2 = [None for _ in range(k + 2)]
    com_TOS_x2, com_TOS_y2, tr2, ts2 = GS_TOS.commit(crs, TOS_x2, TOS_y2, TOS_c_a2, TOS_c_b2)
    TOS_proof2 = GS_TOS.prove(crs, TOS_x2, TOS_y2, tr2, ts2, com_TOS_y2, [gammaT_2])
    # print(GS_TOS.verify(pp, crs, TOS_proof2, com_TOS_x2, com_TOS_y2, [gammaT_2]))
    return ((TOS_proof1, com_TOS_x1, com_TOS_y1, [gammaT_1]), (TOS_proof2, com_TOS_x2, com_TOS_y2, [gammaT_2]))

def verify_TOS_proof(pp, crs, GS_TOS: GS, TOS_pi):
    TOS_pi1, TOS_pi2 = TOS_pi
    TOS_proof1, com_TOS_x1, com_TOS_y1, GammaT_1 = TOS_pi1
    TOS_proof2, com_TOS_x2, com_TOS_y2, GammaT_2 = TOS_pi2
    return GS_TOS.verify(pp, crs, TOS_proof1, com_TOS_x1, com_TOS_y1, GammaT_1) and GS_TOS.verify(pp, crs, TOS_proof2, com_TOS_x2, com_TOS_y2, GammaT_2)


def Unbound_TOS_Sign(gk, pk, sk, tag, msg, block_size):
    group, G, C, F, U = gk
    total_len = len(msg)
    block_num = 1 + math.ceil((total_len - block_size) / (block_size - 3))
    pad_msg = [] + msg + [group.init(G1, 1) for _ in range(total_len - block_size - (block_num - 1) * (block_size - 3))]
    message_block_list = []
    signature_block_list = []
    for i in range(block_num):
        if i == 0: 
            curr_message_block = pad_msg[:block_size]
            curr_signature = []
        else:
            curr_message_block = pad_msg[block_size + (i - 1) * (block_size - 3): block_size + i * (block_size - 3)]
            curr_signature = list(signature_block_list[i - 1])
        message_block_list.append(curr_message_block)
        signature_block_list.append(TOS_Sign(gk, pk, sk, curr_message_block + curr_signature, tag))
    return (message_block_list, signature_block_list)

def Unbound_TOS_Verify(gk, pk, tag, message_block_list, signature_block_list):
    block_num = len(message_block_list)
    for i in range(block_num):
        if i == 0:
            curr_result = TOS_Verify(gk, pk, tag, message_block_list[0], signature_block_list[0])
        else:
            curr_result = TOS_Verify(gk, pk, tag, message_block_list[i] + list(signature_block_list[i - 1]), signature_block_list[i])
        if not curr_result:
            return False
    return True

def generate_Unbound_TOS_proof(gk, pk, tag, message_block_list, signature_block_list, pp, GS_TOS: GS, crs, td):
    block_num = len(message_block_list)
    TOS_pi_list = []
    for i in range(block_num):
        if i == 0:
            TOS_pi_list.append(generate_TOS_proof(gk, pk, tag, message_block_list[0], signature_block_list[0], pp, GS_TOS, crs, td))
        else:
            TOS_pi_list.append(generate_TOS_proof(gk, pk, tag, message_block_list[i] + list(signature_block_list[i - 1]), signature_block_list[i], pp, GS_TOS, crs, td))
    return TOS_pi_list

def verify_Unbound_TOS_proof(pp, crs, GS_TOS: GS, TOS_pi_list):
    for TOS_pi in TOS_pi_list:
        if not verify_TOS_proof(pp, crs, GS_TOS, TOS_pi):
            return False
        
    return True

def rSIG_Key(gk):
    group, G, C, F, U = gk
    V, V1, V2, H = group.random(G1, 4)
    a1, a2, b, alpha, rho = group.random(ZR, 5)
    B = G ** b
    A1 = G ** a1
    A2 = G ** a2
    B1 = G ** (b * a1)
    B2 = G ** (b * a2)
    R1 = V * (V1 ** a1)
    R2 = V * (V2 ** a2)
    W1 = R1 ** b
    W2 = R2 ** b
    X1 = G ** rho
    X2 = G ** (alpha * a1 * b * (rho ** -1))
    K1 = G ** alpha
    K2 = G ** (alpha * a1)

    vk = (B, A1, A2, B1, B2, R1, R2, W1, W2, H, X1, X2)
    sk = (vk, K1, K2, V, V1, V2)

    return vk, sk

def rSIG_Sign(gk, sk, msg):
    M1, M2, M3 = msg
    group, G, C, F, U = gk
    vk, K1, K2, V, V1, V2 = sk
    B, A1, A2, B1, B2, R1, R2, W1, W2, H, X1, X2 = vk

    r1, r2, z1, z2 = group.random(ZR, 4)
    r = r1 + r2

    S0 = (M3 * H) ** r1
    S1 = K2 * (V ** r)
    S2 = (K1 ** -1) * (V1 ** r) * (G ** z1)
    S3 = B ** (-1 * z1)
    S4 = (V2 ** r) * (G ** z2)
    S5 = B ** (-1 * z2)
    S6 = B ** r2
    S7 = G ** r1

    sigma = (S0, S1, S2, S3, S4, S5, S6, S7)
    return sigma

def rSIG_Verify(gk, vk, sigma, msg):
    group, G, C, F, U = gk
    M1, M2, M3 = msg
    B, A1, A2, B1, B2, R1, R2, W1, W2, H, X1, X2 = vk
    S0, S1, S2, S3, S4, S5, S6, S7 = sigma
    if pair(S1, B) * pair(S2, B1) * pair(S3, A1) != pair(S6, R1) * pair(S7, W1):
        print('in rSIG_Verify, eq1 failed')
        return False
    if pair(S1, B) * pair(S4, B2) * pair(S5, A2) != pair(S6, R2) * pair(S7, W2) * pair(X1, X2):
        print('in rSIG_Verify, eq2 failed')
        return False
    if pair(S7, M3 * H) != pair(G, S0):
        print('in rSIG_Verify, eq3 failed')
        return False
    if pair(F, M1) != pair(C, M2):
        print('in rSIG_Verify, eq4 failed')
        return False
    if pair(U, M1) != pair(C, M3):
        print('in rSIG_Verify, eq3 failed')
        return False
    return True

def SIG_Key(gk, k):
    pkt, skt = TOS_Key(gk, k)
    vkr, skr = rSIG_Key(gk)
    vk = (pkt, vkr)
    sk = (skt, skr)
    return vk, sk

def SIG_Sign(gk, sk, vk, msg):
    skt, skr = sk
    pkt, vkr = vk
    tag = TOS_Tag(gk)
    sigma_t = TOS_Sign(gk, pkt, skt, msg, tag)
    sigma_r = rSIG_Sign(gk, skr, tag)
    return (tag, sigma_t, sigma_r)

def SIG_Verify(gk, vk, msg, sigma):
    pkt, vkr = vk
    tag, sigma_t, sigma_r = sigma
    return TOS_Verify(gk, pkt, tag, msg, sigma_t) and rSIG_Verify(gk, vkr, sigma_r, tag)

# def DS_

if __name__ == '__main__':
    gk = SIG_Setup(512)
    group, G, C, F, U = gk

    k = 16
    # msg = [group.random(G1) for _ in range(k)]

    # vk, sk = SIG_Key(gk, k)
    # sigma = SIG_Sign(gk, sk, vk, msg)
    # print(SIG_Verify(gk, vk, msg, sigma))

    tpk, tsk = TOS_Key(gk, k)
    tag1 = TOS_Tag(gk)
    msg = [group.random(G1) for _ in range(k - 1)]
    tsigma = TOS_Sign(gk, tpk, tsk, msg, tag1)
    print(TOS_Verify(gk, tpk, tag1, msg, tsigma))

    # vkr, skr = rSIG_Key(gk)
    # rsigma = rSIG_Sign(gk, skr, tag1)
    # print(rSIG_Verify(gk, vkr, rsigma, tag1))

    msg2 = [group.random(G1) for _ in range(3 * k)]
    tag2 = TOS_Tag(gk)
    pk2, sk2 = TOS_Key(gk, k)
    msg2_list, signature2_list = Unbound_TOS_Sign(gk, pk2, sk2, tag2, msg2, k)
    print(Unbound_TOS_Verify(gk, pk2, tag2, msg2_list, signature2_list))

    g1, g2 = group.random(G1, 2)
    pp={'G1':g1,'G2':g2,'GT':pair(g1,g2)} 
    GS_test = GS(group)
    crs, td = GS_test.Transpatent_Setup(pp)

    # TOS_pi = generate_TOS_proof(gk, tpk, tag1, msg, tsigma, pp, GS_test, crs, td)
    # print(verify_TOS_proof(pp, crs, GS_test, TOS_pi))

    TOS_pi_list = generate_Unbound_TOS_proof(gk, pk2, tag2, msg2_list, signature2_list, pp, GS_test, crs, td)
    print(verify_Unbound_TOS_proof(pp, crs, GS_test, TOS_pi_list))
