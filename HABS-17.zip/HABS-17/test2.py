import sympy as sp
import random

def random_unimodular_block(max_entry=5):
    """
    随机生成一个 2×2 整数矩阵 U，使得 det(U)=±1。
    max_entry 控制随机整数绝对值上限。
    """
    while True:
        a = random.randint(-max_entry, max_entry)
        b = random.randint(-max_entry, max_entry)
        c = random.randint(-max_entry, max_entry)
        d = random.randint(-max_entry, max_entry)
        if a*d - b*c in (1, -1):
            return [[a, b], [c, d]]

def generate_S(m, max_val=10):
    """
    生成一个 m×2 的整数矩阵 S，满足：
      1. rank(S) = 2
      2. 存在 z = [1, 0, ..., 0] 使得 z·S = [1, 0]
    返回值：
      嵌套列表形式的 S，长度为 m，每个元素是长度为 2 的列表。
    
    参数：
      m       -- 矩阵行数，必须 ≥ 2
      max_val -- 随机生成时的元素绝对值上限（正负），默认为 10
    """
    if m < 2:
        raise ValueError("m 必须 ≥ 2")
    
    S = []
    # 前两行固定为基向量 [1,0] 和 [0,1]
    S.append([1, 0])
    S.append([0, 1])
    
    # 其余行随机生成
    for _ in range(2, m):
        a = random.randint(-max_val, max_val)
        b = random.randint(-max_val, max_val)
        S.append([a, b])
    
    return S

def generate_S(m, max_val=10):
    """
    生成一个 m×2 的整数矩阵 S，满足：
      1. rank(S) = 2
      2. 存在 z = [1, 0, ..., 0] 使得 z·S = [1, 0]
    返回值：
      嵌套列表形式的 S，长度为 m，每个元素是长度为 2 的列表。
    
    参数：
      m       -- 矩阵行数，必须 ≥ 2
      max_val -- 随机生成时的元素绝对值上限（正负），默认为 10
    """
    if m < 2:
        raise ValueError("m 必须 ≥ 2")
    
    S = []
    # 前两行固定为基向量 [1,0] 和 [0,1]
    S.append([1, 0])
    S.append([0, 1])
    
    # 其余行随机生成
    for _ in range(2, m):
        a = random.randint(-max_val, max_val)
        b = random.randint(-max_val, max_val)
        S.append([a, b])
    
    return S

def solve_integer_z(S):
    """
    给定 m×2 矩阵 S（列表嵌套列表），
    返回一个整数向量 z 使得 z·S = (1, 0).
    """
    # 矩阵转置
    A = sp.Matrix(S).T      # 2×m
    b = sp.Matrix([1, 0])   # 2×1

    # 构造符号变量 z0...z_{m-1}
    m = len(S)
    zs = sp.symbols(f'z0:{m}')

    # 求通解
    sol_set = sp.linsolve((A, b), *zs)
    sol = next(iter(sol_set))  # 取得第一个解，含参数 t0, t1...

    # 取特解：将所有自由参数设为 0
    free_syms = sol.free_symbols
    subs = {sym: 0 for sym in free_syms}
    sol_part = [sol[i].subs(subs) for i in range(len(sol))]

    # 把分式解转为整数解
    # 找出所有分母的最小公倍数
    denoms = [sp.Rational(val).q for val in sol_part]
    L = sp.ilcm(*denoms)

    # 乘以 L，得到整数向量
    z_int = [int(sp.Rational(val) * L) for val in sol_part]
    return z_int

if __name__ == '__main__':
    # 示例
    S_example = generate_S(100)

    z_int = solve_integer_z(S_example)
    print("整数解 z =", z_int)
    print("验证:", z_int, "* S =", [sum(z_int[i] * S_example[i][j] for i in range(len(z_int))) for j in range(2)])
