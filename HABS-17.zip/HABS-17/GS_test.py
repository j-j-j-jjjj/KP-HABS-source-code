from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair
from Groth_Sahai import GS

group = PairingGroup("SS512", secparam = 512)

g1, g2 = group.random(G1, 2)
# print(pair(g1 ** 4, g2 ** 5) == pair(g1 **  10, g2 ** 2))
# print(g1 ** 1 == g1)
pp={'G1':g1,'G2':g2,'GT':pair(g1,g2)} 
GS_test = GS(group)
crs, td = GS_test.Transpatent_Setup(pp)

a, b, c = group.random(ZR, 3)
A = g1 ** a
B = g2
C = g1
D = g2 ** b
# print(pair(A, B) == pair(C, D))
check_result = pair(g1 ** (a + b), g2)
print(pair(A, B) * (pair(C, D)) == check_result)
x = [A, C]
y = [B, D]
c_a = [None, None]
c_b = [None, None]

gammaT = [[1, 0], [0, 1]]

com_x, com_y, r, s = GS_test.commit(crs, x, y, c_a, c_b)
pi = GS.prove(pp, crs, x, y, r, s, com_y, [gammaT])
print(GS_test.verify(pp, crs, pi, com_x, com_y, [gammaT], check_equal_result=check_result))