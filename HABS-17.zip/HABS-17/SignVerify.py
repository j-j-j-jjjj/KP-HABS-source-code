import time
from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair
from KeyGen import Key_gen, AttIssue
from DS_TS import SIG_Setup, TOS_Tag, TOS_Sign, TOS_Verify, generate_TOS_proof, verify_TOS_proof, generate_Unbound_TOS_proof, verify_Unbound_TOS_proof
from policy_tools import generate_attrTag, generate_S, solve_integer_z, generate_zS_proof, verify_zS_proof
from OTS import OTS_Setup, OTS_KGen, OTS_Sign, OTS_Verify
from PKE import Enc, generate_valid_cipher_proof, verify_valid_cipher_proof
from Groth_Sahai import GS

def list_tuple_flatten(list_tuple):
    flatten_list = []
    # print(list_tuple)
    for element in list_tuple:
        if isinstance(element, list) or isinstance(element, tuple):
            flatten_list += list_tuple_flatten(element)
        else:
            flatten_list.append(element)
    return flatten_list

def NIZK_setup(gk):
    group, G, C, F, U = gk
    GS_g1, GS_g2 = group.random(G1, 2)
    pp={'G1':GS_g1,'G2':GS_g2,'GT':pair(GS_g1,GS_g2)} 
    GS_1 = GS(group)
    crs, td = GS_1.Transpatent_Setup(pp)
    return GS_1, pp, crs, td

def generate_NIZK1_proof(gk, GS_1, pp, crs, td, user_warr, sigma_s, DS_Tag, ovk, upk, pk_TA, cipher, cipher_randomness, z, S, attr_set):
    group, G, C, F, U = gk
    NIZK1_pi_list = []

    DS_pi = generate_TOS_proof(gk, upk, DS_Tag, ovk, sigma_s, pp, GS_1, crs, td)
    NIZK1_pi_list.append(DS_pi)

    cipher_pi = generate_valid_cipher_proof(pk_TA, cipher, cipher_randomness, list_tuple_flatten((upk, sigma_s, ovk)), pp, crs, td, GS_1)
    NIZK1_pi_list.append(cipher_pi)

    zS_pi = generate_zS_proof(z, S, pp, crs, td, GS_1)
    NIZK1_pi_list.append(zS_pi)

    attrNum = len(attr_set)
    for i in range(attrNum):
        # pk_list contains pkd_list and upk
        pk_list, sigma_a_list = user_warr[attr_set[i]]
        depth = len(pk_list) - 1
        for j in range(depth):
            curr_attrIssue_pi = generate_Unbound_TOS_proof(gk, pk_list[j], attr_set[i], sigma_a_list[j][0][:3], sigma_a_list[j][1][:3], pp, GS_1, crs, td)
            NIZK1_pi_list.append(curr_attrIssue_pi)
    return NIZK1_pi_list


def Sign(gk, OTS_pp, upk, usk, pk_TA, user_warr, attr_set, S, GS_1, pp, crs, td, message):
    group, G, C, F, U = gk
    ovk, osk = OTS_KGen(OTS_pp)
    DS_tag = TOS_Tag(gk)
    sigma_s = TOS_Sign(gk, upk, usk, list(ovk), DS_tag)
    cipher, cipher_randomness = Enc(group, G, pk_TA, C, list_tuple_flatten((upk, sigma_s, ovk)))
    z = solve_integer_z(S)
    NIZK1_pi_list = generate_NIZK1_proof(gk, GS_1, pp, crs, td, user_warr, sigma_s, DS_tag, ovk, upk, pk_TA, cipher, cipher_randomness, z, S, attr_set)
    OTS_input = group.hash((message, S, cipher, NIZK1_pi_list))
    OTS_input = group.hash((message, S, cipher))
    sigma_0 = OTS_Sign(OTS_pp, osk, OTS_input)
    return (sigma_0, cipher, NIZK1_pi_list, ovk)
    # return (sigma_0, cipher, ovk)

def Verify(gk, OTS_pp, GS_1, pp, crs, td, S, message, signature):
    group, G, C, F, U = gk
    sigma_0, cipher, NIZK1_pi_list, ovk = signature
    # sigma_0, cipher, ovk = signature
    OTS_input  = group.hash((message, S, cipher, NIZK1_pi_list))
    # OTS_input  = group.hash((message, S, cipher))
    if not OTS_Verify(OTS_pp, ovk, sigma_0, OTS_input):
        return False
    if not verify_TOS_proof(pp, crs, GS_1, NIZK1_pi_list[0]):
        return False
    if not verify_valid_cipher_proof(pp, crs, GS_1, NIZK1_pi_list[1]):
        return False
    if not verify_zS_proof(pp, crs, GS_1, NIZK1_pi_list[2]):
        return False
    for i in range(3, len(NIZK1_pi_list)):
        if not verify_Unbound_TOS_proof(pp, crs, GS_1, NIZK1_pi_list[i]):
            return False
        
    return True

    
    


if __name__ == '__main__':
    gk = SIG_Setup(512)
    group, G, C, F, U = gk
    k = 7
    n = 500
    depth = 2 
    attrNum = 10
    pk_TA, sk_TA, pkd_list, skd_list, upk, usk = Key_gen(gk, k, n, depth)
    attr_set = generate_attrTag(gk, attrNum)
    user_warr = AttIssue(attr_set, gk, k, pkd_list, skd_list, upk)
    OTS_pp = OTS_Setup(group)
    GS_1, pp, crs, td = NIZK_setup(gk)
    S = generate_S(attrNum)
    message = group.random(G1)

    # print('begin Sign')
    # signature = Sign(gk, OTS_pp, upk, usk, pk_TA, user_warr, attr_set, S, GS_1, pp, crs, td, message)
    # verify_result = Verify(gk, OTS_pp, GS_1, pp, crs, td, S, message, signature)
    # print(verify_result)

    sig_time_list = []
    ver_time_list = []
    for _ in range(10):
        print('begin Sign')
        t1 = time.time()
        signature = Sign(gk, OTS_pp, upk, usk, pk_TA, user_warr, attr_set, S, GS_1, pp, crs, td, message)
        t2 = time.time()
        verify_result = Verify(gk, OTS_pp, GS_1, pp, crs, td, S, message, signature)
        t3 = time.time()
        print(verify_result)
        print(f'sign time: {t2 - t1}, verify time: {t3 - t2}')
        sig_time_list.append(t2 - t1)
        ver_time_list.append(t3 - t2)
    
    sig_avg_time = sum(sig_time_list) / 10
    ver_avg_time = sum(ver_time_list) / 10
    print(f"sig_avg_time: {sig_avg_time}")
    print(f"ver_avg_time: {ver_avg_time}")
    print(f"sig_time_list: {sig_time_list}")
    print(f"sig_time_list: {sig_time_list}")