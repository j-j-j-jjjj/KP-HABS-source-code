from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair

group = PairingGroup("SS512")
g1_length = len(group.serialize(group.random(G1)))

for i in range(5):
    attrNum = 10 * (i + 1)
    depth = 3
    print(f'attribute number = {attrNum}, depth = {depth}, length = {g1_length * (2 + attrNum * (depth + 1))}')

for i in range(5):
    attrNum = 10
    depth = 2 * (i + 1)
    print(f'attribute number = {attrNum}, depth = {depth}, length = {g1_length * (2 + attrNum * (depth + 1))}')