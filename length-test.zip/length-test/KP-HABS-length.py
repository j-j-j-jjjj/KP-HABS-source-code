from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair

group = PairingGroup("SS512")
g1_length = len(group.serialize(group.random(G1)))

print(g1_length * 4)