from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, pair

group = PairingGroup("BN254")
g1_length = len(group.serialize(group.random(G1)))
g2_length = len(group.serialize(group.random(G2)))
zp_length = len(group.serialize(group.random(ZR)))

for i in range(5):
    attrNum = 10 * (i + 1)
    depth = 3

    g1_num = 2 + 6 * (2 * depth - 1) * attrNum + 12 + 8
    g2_num = 1 + 4 * (2 * depth - 1) * attrNum + 8 + 2 * depth * attrNum + 8
    zp_num = 1 + attrNum

    print(f'attribute number = {attrNum}, depth = {depth}, length = {g1_length * g1_num + g2_length * g2_num + zp_length * zp_num}')

for i in range(5):
    attrNum = 10
    depth = 2 * (i + 1)

    g1_num = 2 + 6 * (2 * depth - 1) * attrNum + 12 + 8
    g2_num = 1 + 4 * (2 * depth - 1) * attrNum + 8 + 2 * depth * attrNum + 8
    zp_num = 1 + attrNum

    print(f'attribute number = {attrNum}, depth = {depth}, length = {g1_length * g1_num + g2_length * g2_num + zp_length * zp_num}')