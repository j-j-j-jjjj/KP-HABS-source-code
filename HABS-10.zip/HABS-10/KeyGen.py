"""
此模块用于实现Extract以及Delegate这两个密钥生成算法
"""

from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair
from Setup import Setup, P, Q, s_to_b, b_to_s
from parser import parseAttrset

def Extract(S, pp, msk):
    S = parseAttrset(S, pp)
    group, g, g1, g2, AVector, HVector, MVector = pp
    w = group.random(ZR)
    K0 = msk * (g2 ** w)
    Ki0 = []
    Kij = []
    index = 0
    while index < len(S):
        K_index_0 = g2 ** w
        K_index_j = []
        hindex = 0
        while hindex < len(S[index]):
            r_index_j = group.random(ZR)
            K_index_0 *= S[index][hindex] ** r_index_j
            K_index_j.append(g ** r_index_j)
            hindex += 1
        Ki0.append(K_index_0)
        Kij.append(K_index_j)
        index += 1
    # 返回密钥以及对应的属性集合
    return K0, Ki0, Kij, S

def Delegate(pp, K0, Ki0, Kij, S, nextS):
    nextK0 = K0
    nextKi0 = []
    nextKij = []
    S = parseAttrset(S, pp)
    nextS = parseAttrset(nextS, pp)
    group, g, g1, g2, AVector, HVector, MVector = pp
    nextw = group.random(ZR)
    nextK0 *= g2 ** nextw

    for attrVector in nextS:
        if not attrVector[:-1] in S:
            print("cannot delegate this attr key")
            return (None, None, None)
        pre_index = S.index(attrVector[:-1])
        nextr_index_j = group.random(ZR)
        nextP = attrVector[-1] ** nextr_index_j
        nextKi0.append(Ki0[pre_index] * g2 ** nextw * nextP)
        nextKij.append(Kij[pre_index] + [g ** nextr_index_j])
    # 返回密钥以及对应的属性集合
    return nextK0, nextKi0, nextKij, nextS


if __name__ == '__main__':
    pp, msk = Setup(512, 500, 5, 100)
    group, g, g1, g2, AVector, HVector, MVector = pp
    S = '[(a1, a2, a3), (b1, b2, b3), (c1, c2, c3), (d1, d2, d3)]'
    K0, Ki0, Kij, _ = Extract(S, pp, msk)
    nextS1 = '[(a1, a2, a3, a4), (b1, b2, b3, b4)]'
    nextS2 = '[(a1, a2, a3, a4), (d1, b2, b3, b4)]'
    K0, Ki0, Kij, _ = Delegate(pp, K0, Ki0, Kij, S, nextS1)
    if K0:
        print(K0)
        print(len(Ki0))
        print(len(Kij))
        print(len(Kij[0]))
    
    nextS3 = '[(a1, a2, a3, a4, a5)]'
    K0, Ki0, Kij, _ = Delegate(pp, K0, Ki0, Kij, nextS1, nextS3)
    if K0:
        print(K0)
        print(len(Ki0))
        print(len(Kij))
        print(len(Kij[0]))