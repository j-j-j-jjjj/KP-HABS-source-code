"""
此模块主要用于实现各类编码转换函数
"""
from collections import deque
from Setup import Setup, Q, P, b_to_s, s_to_b
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair

class TreeNode:
    def __init__(self, left, right, type, attr):
        self.left = left    # 左子树
        self.right = right   # 右子树
        self.type = type    # 节点类型: "and", "or", "leaf"
        self.attr = attr  # 如果是leaf类型，有属性
        self.vector = None

class lexer:
    def __init__(self, string: str):
        # 去掉表达式中所有空格
        self.text = string.replace(' ', '')
        self.index = 0

    # 每调用一次read_token,读取policy中的一个"[", "]"或一个属性向量或一个连接词
    # 也可以读取userset中的一个属性向量，每次一个
    def read_token(self):
        while self.index < len(self.text):
            c = self.text[self.index]
            # 读取到userset的()之间的","
            if c == ',':
                self.index += 1
                continue

            if c == '[':
                self.index += 1
                return '['

            if c == ']':
                self.index += 1
                return ']'

            # if (c.isalpha() or c.isdigit()) or c == '_':
            if c == '(':
                self.index += 1
                attr_vector = []
                f = self.index
                while True:
                    c = self.text[self.index]
                    if c == ',':
                        # print(f'one dimension: {self.text[f: self.index]}')
                        attr_vector.append(self.text[f: self.index])
                        self.index += 1
                        f = self.index
                        continue
                    if c == ')':
                        # print(f'one dimension: {self.text[f: self.index]}')
                        attr_vector.append(self.text[f: self.index])
                        self.index += 1
                        break
                    self.index += 1
                    # 切出一个分量
                    # print(f'one dimension: {self.text[f: self.index]}')
                    # attr_vector.append(self.text[f: self.index])
                    # if c == ',' or c == ' ':
                    #     continue
                return attr_vector
            
            if self.text[self.index: self.index + 3] == 'and':
                self.index += 3
                return 'and'

            if self.text[self.index: self.index + 2] == 'or':
                self.index += 2
                return 'or'

            if self.index == len(self.text):
                return ""

            raise ValueError("bad policy(%s) at %d" % (self.text, self.index))

        return ""

def parseTree(expression: str, pp):
    group, g, g1, g2, AVector, HVector, MVector = pp
    expList = []
    pLexer = lexer(expression)
    # 接收当前读取的策略
    while pLexer.index < len(expression.replace(' ', '')):
        token = pLexer.read_token()
        # 如果是层次化属性向量
        if type(token) == type([]):
            # print(token)
            hindex = 0
            h_attr_vector = []
            while hindex < len(token):
                h_attr_vector.append(P(HVector[hindex], s_to_b(token[hindex]), AVector))
                hindex += 1
            # print(f'parseTree, h_attr_vector = {h_attr_vector}')
            expList.append(h_attr_vector)
            continue
        expList.append(token)
    # print(expList)
    # 构建布尔树
    index, rootNode = constructTree(0, expList)
    # printTree(rootNode=rootNode)
    return rootNode

def constructTree(index, expList):
    # 读取到的是左边的操作数标记
    lFlag = True
    # 左右操作数对应的节点和中间操作符对应的节点
    lNode = TreeNode(None, None, None, None)
    rNode = TreeNode(None, None, None, None)
    iNode = TreeNode(None, None, None, None)

    while index < len(expList):
        # 如果是(，则递归构造子树
        if expList[index] == "[":
            if lFlag:
                index, lNode = constructTree(index + 1, expList)
                iNode.left = lNode
            else:
                index, rNode = constructTree(index + 1, expList)
                lFlag = True
                iNode.right = rNode

            
        elif expList[index] == "]":
            # print(index, iNode.type, iNode.left.type, iNode.right.type)
            return index + 1, iNode
        elif expList[index] == "and" or expList[index] == "or":
            lFlag = False
            iNode.left = lNode
            iNode.type = expList[index]
            index = index + 1
        else:
            if lFlag:
                lNode.type = "leaf"
                lNode.left = None
                lNode.right = None
                lNode.attr = expList[index]
                index = index + 1
            else:
                rNode.type = "leaf"
                rNode.left = None
                rNode.right = None
                rNode.attr = expList[index]
                iNode.right = rNode
                index = index + 1
                lFlag = True
    # print(index, iNode.type, iNode.left.type, iNode.right.type)    
    return index, iNode

# 先序遍历打印布尔树
def printTree(rootNode: TreeNode):
    if rootNode.type == "and" or rootNode.type == "or":
        printTree(rootNode.left)
        print(rootNode.type)
        printTree(rootNode.right)
    else:
        print(rootNode.attr)

# 将布尔树编码为lsss矩阵
def parseMatrix(rootNode: TreeNode):
    # 对于此lsss矩阵，第一列是各行对应的属性，其余列才是编码后的向量
    lsssMatrix = []
    if not rootNode:
        return
    counter = 1
    rootNode.vector = [1]
    nodeQueue = deque([rootNode])
    # 采取广度优先搜索
    while len(nodeQueue) > 0:
        curNode = nodeQueue.popleft()
        if curNode.type != "leaf":
            nodeQueue.append(curNode.left)
            nodeQueue.append(curNode.right)
        # 如果当前节点是or类型，将它的两个子结点的向量标注为与它相同，并保持counter不变
        if curNode.type == "or":
            curNode.left.vector = curNode.vector[::]
            curNode.right.vector = curNode.vector[::]
        # 当前节点是and类型
        elif curNode.type == "and":
            while counter - len(curNode.vector) > 0:
                curNode.vector.append(0)
            curNode.left.vector = [0 for _ in range(counter)]
            curNode.left.vector.append(-1)
            curNode.right.vector = curNode.vector[::]
            curNode.right.vector.append(1)
            counter = counter + 1
        # 当前节点是leaf类型
        else:
            # 将该节点的向量加入lsss矩阵
            lsssMatrix.append([curNode.attr] + curNode.vector)
    # 对lsss矩阵中长度不足的补0
    for eachRow in lsssMatrix:
        while counter + 1 - len(eachRow) > 0:
                eachRow.append(0)
    return lsssMatrix

# 将用户属性集合编码为与lsss矩阵第一列适配的格式
def parseAttrset(attr_set: str, pp):
    group, g, g1, g2, AVector, HVector, MVector = pp
    parsed_set = []
    slexer = lexer(attr_set)
    # print(slexer.text)
    while slexer.index < len(attr_set.replace(' ', '')):
        token = slexer.read_token()
        if type(token) == type([]):
            # print(token)
            # print(len(parsed_set))
            hindex = 0
            h_attr_vector = []
            while hindex < len(token):
                h_attr_vector.append(P(HVector[hindex], s_to_b(token[hindex]), AVector))
                hindex += 1
            # print(f'parseAttrset, h_attr_vector = {h_attr_vector}')
            # attr_vector.append(h_attr_vector)
            parsed_set.append(h_attr_vector)
    # print(f'parseAttrset, parsed_set = {parsed_set}')
    return parsed_set




if __name__ == '__main__':
    expression = "[(a1, a2) and (b1, b2)] or [(c1, c2) and (d1, d2)]"
    pp, msk = Setup(512, 500, 5, 100)
    pLexer = lexer(expression)
    # userset = ['(a1, a2)', '(b1, b2)', '(c1, c2)']
    userset = '[(a1, a2), (b1, b2), (c1, c2)]'

    rootnode = parseTree(expression, pp)
    # print(parseMatrix(rootNode=rootnode))
    lsssMatrix = parseMatrix(rootNode=rootnode)
    # for row in lsssMatrix:
    #     print(row[1:])
    lsss_set = []
    for element in lsssMatrix:
        lsss_set.append(element[0])
    parsed_set = parseAttrset(userset, pp)
    counter = 0
    # print(f"main, parsed_set = {parsed_set}")
    # print(type(parsed_set[0]))
    # print(len(lsss_set))
    for elment in parsed_set:
        if elment in lsss_set:
            counter += 1
    print(counter)