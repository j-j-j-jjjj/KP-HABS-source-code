# import charm
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair

# 初始化一个双线性配对群
group = PairingGroup('SS512')
# 获取 ZR 的单位元
unit_element = group.init(ZR, 1)

# 获取 ZR 的零元
zero_element = group.init(ZR, 0)
# 生成Zp上的随机数
a = group.random(ZR)
b = group.random(ZR)
c = group.random(ZR)
d = group.random(ZR)
# 两个G1群的生成元
g1 = group.random(G1)
g2 = group.random(G1)

s1 = pair(g1 ** a, g1 ** b) / (pair(g2 ** c, g2) * pair(g2 ** d, g2))
s2 = (pair(g1 ** a, g1 ** b) / pair(g2 ** c, g2)) / pair(g2 ** d, g2)
# print(s1 == s2)
# print(pair(g1, g2) == pair(g2, g1))
# print((g1 ** 0) * g2 == g2)
# print(g1 ** (-1) ** (-2) == g1 * g1)
def ZR_INT_EXP(z, exponent):
    if exponent < 0:
        # return z ** (-1) ** (-exponent)
        z = z ** (-1)
        res = z
        exponent = (-exponent) - 1
        while exponent:
            if exponent & 1:  # 判断当前的最后一位是否为1，如果为1的话，就需要把之前的幂乘到结果中。
                res *= z
            z *= z  # 一直累乘，如果最后一位不是1的话，就不用了把这个值乘到结果中，但是还是要乘。
            exponent = exponent >> 1
        return res
    elif exponent == 0:
        return z ** 0
    else:
        res = z
        exponent -= 1
        while exponent:
            if exponent & 1:  # 判断当前的最后一位是否为1，如果为1的话，就需要把之前的幂乘到结果中。
                res *= z
            z *= z  # 一直累乘，如果最后一位不是1的话，就不用了把这个值乘到结果中，但是还是要乘。
            exponent = exponent >> 1
        return res

print(g2 / g1 / g1 == g2 * g1 ** (-1) * g1 ** (-1))
print(g2 * ZR_INT_EXP(g1, -2) == (g2 / g1) / g1)
 