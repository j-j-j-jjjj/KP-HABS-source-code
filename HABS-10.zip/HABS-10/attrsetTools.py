import random


# 随机产生属性集合字符串
def generateAttrset(depth, num, length): 
    attrSetStr = "["
    attrSet = []
    for i in range(num):
        hAttrVector = "("
        for j  in range(depth):
            for k in range(length):
                hAttrVector += str(random.randint(0, 10))
            if j == depth - 1:
                hAttrVector += ')'
            else:
                hAttrVector += ', '
        attrSet.append(hAttrVector)
        if i == num - 1:
            attrSetStr += hAttrVector + ']'
        else:
            attrSetStr += hAttrVector + ', '
    return attrSetStr, attrSet

# 生成表达式
def generateExpression(attrSet):
    expAttrSet = attrSet[::]
    expressionStr = ''
    if len(expAttrSet) % 2 != 0:
        subExpression = str(expAttrSet.pop())
        expressionStr += subExpression + ' or '
    i = 0
    while i < len(expAttrSet):
        subset = expAttrSet[i:i+2]
        expressionStr += '[' + subset[0] + ' and '
        expressionStr += subset[1] + ']'
        if i != len(expAttrSet) - 2:
            expressionStr += ' or '
        i += 2
    return expressionStr

# 生成下一层的属性集合
def generateNextSet(attrSet, num, length):
    nextAttrSet = []
    nextAttrStr = '['
    for i in range(num):
        parentIndex = random.randint(0, len(attrSet) - 1)
        # print(f'next len attrSet: {len(attrSet)}')
        # print(f'next index: {parentIndex}')
        nextAttrVector = attrSet[parentIndex][:-1] + ', '
        for j in range(length):
            nextAttr = random.randint(0, 10)
            nextAttrVector += str(nextAttr)
            if j == length - 1:
               nextAttrVector += ')' 
        nextAttrSet.append(nextAttrVector)
        if i == num - 1:
            nextAttrStr += nextAttrVector + ']'
        else:
            nextAttrStr += nextAttrVector + ', '
    return nextAttrStr, nextAttrSet

# 选择子集并生成字符串
def chooseSubset(attrSet, num):
    subsetStr = '['
    subset = []
    if num > len(attrSet):
        print('chooseSubset Error')
        return False, False
    for i in range(num):
        while True:
            index = random.randint(0, len(attrSet) - 1)
            # print(f'ch len attrSet: {len(attrSet)}')
            # print(f'ch index: {index}')
            if not attrSet[index] in subset:
                subset.append(attrSet[index])
                if i == num - 1:
                    subsetStr += attrSet[index] + ']'
                else:
                    subsetStr += attrSet[index] + ', '
                break
    return subsetStr, subset




if __name__ == '__main__':
    attrSetStr, attrSet = generateAttrset(4, 5, 3)
    print(attrSetStr)
    # print(f'*****{len(attrSet)}')
    expressionStr = generateExpression(attrSet)
    print(expressionStr)
    # print(f'$$$$$${len(attrSet)}')
    nextAttrStr, nextAttrSet = generateNextSet(attrSet, 4, 3)
    print(nextAttrStr)
    subsetStr, subset = chooseSubset(attrSet, 3)
    print(subsetStr)



    