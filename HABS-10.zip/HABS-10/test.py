# import charm
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, pair
print("Hello!!!")
# 初始化一个双线性配对群
group = PairingGroup('SS512')
 
# 生成随机元素
a = group.random(ZR)
b = group.random(ZR)
 
# G1 和 G2 群的生成元
g1 = group.random(G1)
g2 = group.random(G2)
 
# 计算 A = g1^a 和 B = g2^b
A = g1 ** a
B = g2 ** b
 
# 计算 e(A, B) 和 e(g1, g2)^(a*b)
pairing_result1 = pair(A, B)
pairing_result2 = pair(g1, g2) ** (a * b)
 
# 检查这两个结果是否相同
print("e(A, B):", pairing_result1)
print("e(g1, g2)^(a*b):", pairing_result2)
print("Pairing results are equal:", pairing_result1 == pairing_result2)
 
# 双线性配对相乘性质，计算 e(g1, g2^(x1m1+x2m2)) 和 e(g1^x1, g2^m1)*e(g1^x2, g2^m2)
x1, x2, m1, m2 = 2, 3, 4, 5
pairing_result1 = pair(g1, g2 ** (x1 * m1 + x2 * m2))
pairing_result2 = pair(g1 ** x1, g2 ** m1)
pairing_result3 = pair(g1 ** x2, g2 ** m2)
pairing_result = pairing_result2 * pairing_result3
 
# 检查这两个结果是否相同
print("Pairing results are equal:", pairing_result1 == pairing_result)
