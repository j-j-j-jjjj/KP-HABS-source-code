"""
包含了Setup等算法
"""
from numpy import *
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair

# 明文字符串到01字符串的转化
def s_to_b(text: str):
    return ''.join(format(byte, '08b') for byte in text.encode('utf-8'))
def b_to_s(binary_string: str):
    return ''.join(chr(int(binary_string[i:i+8], 2)) for i in range(0, len(binary_string), 8))

def Setup(secParameter, na, nl, nmax):
    # 根据安全参数初始化一个双线性配对群
    group = PairingGroup('SS512', secparam=secParameter)
    # 随即选择一个G1上的生成元
    g = group.random(G1)

    alpha = group.random(ZR)
    g1 = g ** alpha
    g2 = group.random(G1)
    msk = g2 ** alpha
    AVector = [group.random(G1) for _ in range(na)]
    HVector = [group.random(G1) for _ in range(nl)]
    MVector = [group.random(G1)] + [group.random(G1) for _ in range(nmax)]
    pp = (group, g, g1, g2, AVector, HVector, MVector)
    return pp, msk

# 处理属性和消息比特串的函数
def P(Hj, a, AVector):
    Pj_a = Hj
    len_a = len(a)
    index = 0
    while index < len_a:
        if a[index] == '1':
            Pj_a *= AVector[index]
        index += 1
    return Pj_a

def Q(m, MVector):
    Qm = MVector[0]
    len_m = len(m)
    index = 0
    while index < len_m:
        if m[index] == '1':
            Qm *= MVector[index + 1]
        index += 1
    return Qm


            

if __name__ == "__main__":
    pp, msk = Setup(512, 500, 5, 100)
    group, g, g1, g2, AVector, HVector, MVector = pp
    print(pair(g1, g2) == pair(g, msk))
    print(len(AVector), len(HVector), len(MVector))