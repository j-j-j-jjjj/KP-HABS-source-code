"""
此模块用于实现lsss的访问控制结构，包括秘密的分享和恢复
"""
from parser import parseMatrix, parseTree, b_to_s, s_to_b, parseAttrset
from numpy import *
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair
from Setup import Setup
import sympy as sp

# 定义int与ZP类型的乘法， 目前仅支持int为0, 1, -1
def ZR_INT_multiple(z, i, group):
    if i == 0:
        return group.init(ZR, 0)
    elif i == 1:
        return z
    else:
        return -z
    
# 实现群元素整数次乘方，并使用快速幂算法加速
def G_INT_EXP(g, exponent):
    if exponent < 0:
        # return z ** (-1) ** (-exponent)
        g = g ** (-1)
        res = g
        exponent = (-exponent) - 1
        while exponent:
            if exponent & 1:  # 判断当前的最后一位是否为1，如果为1的话，就需要把之前的幂乘到结果中。
                res *= g
            g *= g  # 一直累乘，如果最后一位不是1的话，就不用把这个值乘到结果中，但是还是要乘。
            exponent = exponent >> 1
        return res
    elif exponent == 0:
        return g ** 0
    else:
        res = g
        exponent -= 1
        while exponent:
            if exponent & 1:  # 判断当前的最后一位是否为1，如果为1的话，就需要把之前的幂乘到结果中。
                res *= g
            g *= g  # 一直累乘，如果最后一位不是1的话，就不用把这个值乘到结果中，但是还是要乘。
            exponent = exponent >> 1
        return res

# 借助sympy实现解方程组得到omega
def solve(reconMatrix, rightVector):
    # 定义未知数
    symbolStr = ''
    for i in range(len(reconMatrix[0])):
        symbolStr += f'x{i} '
    xList = sp.symbols(symbolStr)
    
    # 求解线性系统（返回参数化解，解集为 FiniteSet）
    reconMatrix = sp.Matrix(reconMatrix)
    rightVector = sp.Matrix(rightVector)
    sol_set = sp.linsolve((reconMatrix, rightVector), xList)
    if not len(sol_set):
        return False
    sol = next(iter(sol_set))

    # 提取自由参数（返回一个集合）
    free_params = sol.free_symbols

    # 为所有自由参数指定默认值0，从而得到特定解
    subs_dict = {param: 0 for param in free_params}
    particular_sol = list(expr.subs(subs_dict) for expr in sol)
    return particular_sol


def lsssShare(value, lsssMatrix, group):
    end = len(lsssMatrix[0]) - 1
    index = 2
    secretVector = [value]
    lambdaVector = []
    while index <= end:
        secretVector.append(group.random(ZR))
        index = index + 1
    # print("secretvector: ", secretVector)
    # print(end)
    for row in lsssMatrix:
        index = 1
        cur = 0
        while index <= end:
            # print(row[index])
            cur += ZR_INT_multiple(secretVector[index - 1], row[index], group)
            index += 1
        lambdaVector.append(cur)

    return lambdaVector

def lsssRecon(attrSet, lsssMatrix):
    # attrSet = parseAttrset(attrSet, pp)
    reconMatrix = []
    reconLambdaIndex = []
    index = 0
    while index < len(lsssMatrix):
        if lsssMatrix[index][0] in attrSet:
            reconMatrix.append(lsssMatrix[index][1:])
            reconLambdaIndex.append(index)
        index += 1
        
    rightVector = [1] + [0]*(len(lsssMatrix[0]) - 2)
    # 需要转置一下
    reconMatrix = [[reconMatrix[j][i] for j in range(len(reconMatrix))] for i in range(len(reconMatrix[0]))]
    # print(rightVector)
    # print(reconMatrix)
    omegaVector = solve(reconMatrix, rightVector)
    if not omegaVector:
        return False
    return omegaVector
    # try:
    #     pinv_reconMatrix = linalg.pinv(reconMatrix)
    #     omegaVector = dot(pinv_reconMatrix, rightVector)
    #     return omegaVector.astype(int).tolist(), reconLambdaIndex
    # except:
    #     # print("the attr set cannot reconstruct")
    #     return False, False
    
# 用于判断一个属性集合是否满足该访问结构，即是否能恢复出秘密值
def lsssCheck(pp, attrSet, lsssMatrix):
    group, g, g1, g2, AVector, HVector, MVector = pp
    # 待分享的秘密值
    value = group.random(ZR)
    lambdaVector = lsssShare(value, lsssMatrix, group)
    omegaVector = lsssRecon(attrSet, lsssMatrix)
    print(omegaVector)
    if omegaVector:
        # index = 0
        # reconValue = 0    
        # while index < len(omegaVector):
        #     reconValue += ZR_INT_multiple(lambdaVector[reconLambdaIndex[index]], omegaVector[index], group)
        #     index += 1
        # return reconValue == value
        return omegaVector
        # print("the attrset has reconstructed the secret value")
    else:
        return False
        # print("the attribute set cannot reconstruct the value")





if __name__ == '__main__':
    expression = "[(a1, a2, a3) and (b1, b2, b3)] or [(c1, c2, c3) and (d1, d2, d3)]"  # 示例表达式
    expression2 = "[(a1, a2, a3, a4, a5, a6) and (b1, b2, b3, b4, b5, b6)] or [(c1, c2, c3, c4, c5, c6) and (d1, d2, d3, d4, d5, d6)]"
    pp, msk = Setup(512, 500, 8, 100)
    rootNode = parseTree(expression2, pp)
    lsssMatrix = parseMatrix(rootNode)
    attrSet1 = '[(a1, a2), (c1, c2)]'
    attrSet2 = '[(a1, a2, a3), (b1, b2, b3), (c1, c2, c3), (x1, x2, x3)]'
    attrSet3 = '[(a1, a2, a3, a4, a5, a6), (b1, b2, b3, b4, b5, b6), (c1, c2, c3, c4, c5, c6), (d1, d2, d3, d4, d5, d6), (e1, e2, e3, e4, e5, e6), (g1, g2, g3, g4, g5, g6), (x1, x2, x3, x4, x5, x6)]'
    attrSet3 = parseAttrset(attrSet3, pp)
    if lsssCheck(pp, attrSet3, lsssMatrix):
        print("the attrset has reconstructed the secret value")
    else:
        print("the attribute set cannot reconstruct the value")
