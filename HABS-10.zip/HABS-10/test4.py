# import sympy as sp

# # 定义未知数
# xlist = []
# symbolStr = ''
# for i in range(3):
#     symbolStr += f'x{i} '
# xlist = sp.symbols(symbolStr)
# # print(xlist)
# # 构造系数矩阵 A 和右侧向量 b
# A = sp.Matrix([[1, 2, 3]])
# b = sp.Matrix([6])

# # 求解线性系统（返回参数化解，解集为 FiniteSet）
# sol_set = sp.linsolve((A, b), xlist)
# print(not len(sol_set))
# sol = next(iter(sol_set))

# # 提取自由参数（返回一个集合）
# free_params = sol.free_symbols

# # 为所有自由参数指定默认值（例如都设为 0），从而得到特定解
# subs_dict = {param: 0 for param in free_params}
# particular_sol = list(expr.subs(subs_dict) for expr in sol)
# print("默认所有自由参数为 0 时的特定解：", particular_sol)

# import sympy as sp

# # 定义未知数
# x1, x2 = sp.symbols('x1 x2')

# # 定义系数矩阵 A 和向量 b
# A = sp.Matrix([[0, 0],
#                [-1, 0],
#                [0, -1]])
# b = sp.Matrix([1, 0, 0])

# # 求解线性系统
# solution = sp.linsolve((A, b), (x1, x2))
# print(not len(solution))
# import random

# list = [1, 2, 3, 4]
# print(list.pop())
# print(list)
# str1 = '(1, 2, 3)'
# print(str1[:-1])
# print(random.randint(0, 3))

import sys
# 获取签名的字节数
def get_total_size(obj):
    size = sys.getsizeof(obj)
    if isinstance(obj, list) or isinstance(obj, tuple):
        for item in obj:
            size += get_total_size(item)
    return size

x = [1, 2, 3, [4, 5, 6, 7], '12345']
y = (1, 2, 3, [4, 5, 6, 7, 9, (10, 11)], '12345')
print(sys.getsizeof(x))
print(get_total_size(x))
print(sys.getsizeof(y))
print(get_total_size(y))