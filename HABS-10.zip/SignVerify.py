"""
此模块包含Sign和Verify算法，以及演示完整的算法流程
"""
import sys
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, pair
from parser import parseMatrix, parseTree, b_to_s, s_to_b, parseAttrset
from Setup import Setup, Q, P, b_to_s, s_to_b
from KeyGen import Extract, Delegate
from lsss import lsssShare, lsssRecon, G_INT_EXP
from attrsetTools import generateExpression, generateAttrset, generateNextSet, chooseSubset
import time

def Sign(pp, m, K0, Ki0, Kij, S, lsssMatrix: list):
    group, g, g1, g2, AVector, HVector, MVector = pp
    Qm = Q(s_to_b(m), MVector)
    rm = group.random(ZR)
    sigma_i = []
    sigma_ij = []
    lsss_set = []
    hat_S = []
    for element in lsssMatrix:
        lsss_set.append(element[0])
    index = 0
    while index < len(lsss_set):
        if lsss_set[index] in S:
            sigma_i.append((Qm ** rm) * Ki0[index])
            sigma_ij.append(Kij[index])
            hat_S.append([lsss_set[index], index])
        index += 1
    sigma_0 = g ** rm
    sigma_1 = K0
    return sigma_0, sigma_1, sigma_i, sigma_ij, hat_S
    
    
def Verify(pp, m, sigma_0, sigma_1, sigma_i, sigma_ij, hat_S, lsssMatrix):
    hat_S_attr = []
    for element in hat_S:
        hat_S_attr.append(element[0]) 
    omegaVector = lsssRecon(hat_S_attr, lsssMatrix)
    if not omegaVector:
        return False, "the attrset does not satisfy the policy"
    group, g, g1, g2, AVector, HVector, MVector = pp
    # 待分享的秘密值
    value = group.random(ZR)
    lambdaVector = lsssShare(value, lsssMatrix, group)
    # 等式的左边部分
    leftPart = pair(g1, g2 ** value)
    index = 0
    while index < len(hat_S):
        row_index = hat_S[index][1]
        frac = pair(sigma_i[row_index], g ** lambdaVector[row_index])
        column_index = 0
        while column_index < len(sigma_ij[row_index]):
            frac /= pair(sigma_ij[row_index][column_index] ** lambdaVector[row_index], hat_S_attr[index][column_index])
            column_index += 1
        # if omegaVector[index] < 0:
        #     while omegaVector[index]
        # leftPart *= frac ** omegaVector[index]
        leftPart *= G_INT_EXP(frac, omegaVector[index])
        # print(f"testFrac: {frac == pair(g2 ** w * Q(s_to_b(m), MVector) ** rm, g ** lambdaVector[row_index])}")
        index += 1

    index = 0
    testResult = 0
    while index < len(hat_S):
        row_index = hat_S[index][1]
        testResult += omegaVector[index] * lambdaVector[row_index]
        index += 1
    # print(f"testResult: {testResult == value}")
    # print(f"testResult2: {leftPart == pair(g1, g2 ** value) * pair(g2 ** w * Q(s_to_b(m), MVector) ** rm, g) ** testResult}")

    # 等式的右边部分
    rightPart = pair(sigma_1, g ** value) * pair(Q(s_to_b(m), MVector) ** value, sigma_0)
    # rightPart = pair(msk, g ** value) * pair((g2**w) * (Q(s_to_b(m), MVector) ** rm), g ** value)
    if leftPart == rightPart:
        return True, "valid signature for the policy"
    else:
        return False, "Invalid signature"


def HABS_Process():
    pp, msk = Setup(512, 500, 20, 100)
    group, g, g1, g2, AVector, HVector, MVector = pp

    for i in range(5):
        attrNum = 10 * (i + 1)
        depth = 3
        userSetStr, userSet = generateAttrset(depth, attrNum, 2)
        # nextUserSetStr, nextUserSet = generateNextSet(userSet, 10, 2)
        expression = generateExpression(userSet)
        K0, Ki0, Kij, attrSet = Extract(userSetStr, pp, msk)
        # nextK0, nextKi0, nextKij, nextattrSet = Delegate(pp, K0, Ki0, Kij, userSetStr, nextUserSetStr) 
        m = "Hello World"
        rootNode = parseTree(expression, pp)
        lsssMatrix = parseMatrix(rootNode)
        time1 = time.time()
        sigma_0, sigma_1, sigma_i, sigma_ij, hat_S = Sign(pp, m, K0, Ki0, Kij, attrSet, lsssMatrix)
        time2 = time.time()
        result, message = Verify(pp, m, sigma_0, sigma_1, sigma_i, sigma_ij, hat_S, lsssMatrix)
        time3 = time.time()
        print(message)
        print(f'attrnum = {attrNum}, depth = {depth}, sign time = {time2 - time1}, verify time = {time3 - time2}')
    for i in range(5):
        attrNum = 10
        depth = 2 * (i + 1)
        userSetStr, userSet = generateAttrset(depth, attrNum, 2)
        # nextUserSetStr, nextUserSet = generateNextSet(userSet, 10, 2)
        expression = generateExpression(userSet)
        K0, Ki0, Kij, attrSet = Extract(userSetStr, pp, msk)
        # nextK0, nextKi0, nextKij, nextattrSet = Delegate(pp, K0, Ki0, Kij, userSetStr, nextUserSetStr) 
        m = "Hello World"
        rootNode = parseTree(expression, pp)
        lsssMatrix = parseMatrix(rootNode)
        sum_sign_time = 0
        sum_verify_time = 0
        for j in range(10):
            time1 = time.time()
            sigma_0, sigma_1, sigma_i, sigma_ij, hat_S = Sign(pp, m, K0, Ki0, Kij, attrSet, lsssMatrix)
            time2 = time.time()
            result, message = Verify(pp, m, sigma_0, sigma_1, sigma_i, sigma_ij, hat_S, lsssMatrix)
            time3 = time.time()
            sum_sign_time += time2 - time1
            sum_verify_time += time3 - time2
        print(message)
        print(f'attrnum = {attrNum}, depth = {depth}, sign time = {sum_sign_time / 10}, verify time = {sum_verify_time / 10}')


if __name__ == '__main__':
    HABS_Process()