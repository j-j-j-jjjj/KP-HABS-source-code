from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair
from math import prod
from TBE import TBE_KGen
from Groth_Sahai import GS

def Setup():
    group = PairingGroup("BN254", secparam = 512)
    g1, g2 = (group.random(G1), group.random(G2))
    r, s = group.random(ZR, 2)
    h1 = g1 ** s
    h2 = g1 ** (s * s)
    h3 = g1 ** r
    h4 = g1 ** (r * r)
    h5 = g1 ** (r * s)
    f1 = g2 ** s
    f2 = g2 ** r
    g1_tilde, g2_tilde = (group.random(G1), group.random(G2))
    zeta = pair(g1_tilde, g2_tilde)
    TBE_pp = (group, g1, g2)
    tpk, tsk = TBE_KGen(TBE_pp)
    GS_1 = GS(group)
    GS_pp = {'G1':g1,'G2':g2,'GT':pair(g1,g2)}
    crs, _ = GS_1.Transpatent_Setup(GS_pp)
    mr, ms, nr, ns = group.random(ZR, 4)
    a0, b0 = group.random(G1, 2)
    gr = g2 ** mr
    gs = g2 ** ms
    hr = g2 ** nr
    hs = g2 ** ns
    c = pair(a0, gr) * pair(b0, gs)
    d = pair(a0, hr) * pair(b0, hs)
    Delta = mr * ns - nr * ms
    alpha = ns / Delta
    beta = -ms / Delta
    gamma = -nr / Delta
    delta = mr / Delta

    tk = (mr, ms, nr, ns, alpha, beta, gamma, delta)
    G_mathcal = (group, g1, g2, h1, h2, h3, h4, h5, f1, f2)
    pp = (G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1)
    msk = (r, s)
    return pp, msk

def KGen(pp):
    G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1 = pp
    group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    mr, ms, nr, ns, alpha, beta, gamma, delta = tk
    group: PairingGroup
    x, y = group.random(ZR, 2)
    X = h1 ** x
    Y = h3 ** y
    Z = (h2 ** x) * (h5 ** y)
    Z_hat = (h5 ** x) * (h4 ** y)
    pk = (X, Y, Z, Z_hat)
    sk = (x, y)
    return (pk, sk)

def AttIssue(pp, apki, aski, pk_next, att, ai, bi, warr: list):
    G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1 = pp
    group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    mr, ms, nr, ns, alpha, beta, gamma, delta = tk
    group: PairingGroup
    X, Y, Z, Z_hat = pk_next
    xi, yi = aski

    # if not (pair(X * Y, h1) == pair(Z, g2) and pair(X * Y, h3) == pair(Z_hat, g2)):
    #     print('AttIssue failed')
    #     return False
    
    t1, t2 = group.random(ZR, 2)
    T1 = f1 ** t1
    T2 = f2 ** t2
    T3 = g2 ** t1
    T4 = g2 ** t2

    # print(pair(g1, T1 * T2) == pair(h1, T3) * pair(h3, T4))

    aj = ai * ((h2 ** t1) * (h5 ** t2)) ** (-xi) * (Z * (h1 ** att)) ** (-t1)
    bj = bi * ((h5 ** t1) * (h4 ** t2)) ** (-yi) * (Z_hat * (h3 ** att)) ** (-t2)
    # aj = a_tilde ** alpha * b_tilde ** beta
    # bj = a_tilde ** gamma * b_tilde ** delta
    warr_next = warr + [(apki, T1, T2, T3, T4)]
    return (aj, bj, warr_next)

def SystemSetup(attrNum, depth):
    pp, msk = Setup()
    G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1 = pp
    group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    mr, ms, nr, ns, alpha, beta, gamma, delta = tk
    group: PairingGroup

    attrList = group.random(ZR, attrNum)
    # generate pk, sk for authorities and user
    apk_list = []
    ask_list = []
    for _ in range(depth):
        curr_apk, curr_ask = KGen(pp)
        apk_list.append(curr_apk)
        ask_list.append(curr_ask)
    upk, usk = KGen(pp)
    # the warr, a, b of authorities and user
    warr_list = [[[]] for _ in range(attrNum)]
    a_list = [[a0] for _ in range(attrNum)]
    b_list = [[b0] for _ in range(attrNum)]

    for i in range(attrNum):
        # print(f'i = {i}')
        for j in range(depth - 1):
            # print(f'j = {j}')
            curr_a, curr_b, curr_warr = AttIssue(pp, apk_list[j], ask_list[j], apk_list[j + 1], attrList[i], a_list[i][j], b_list[i][j], warr_list[i][j])
            warr_list[i].append(curr_warr)
            a_list[i].append(curr_a)
            b_list[i].append(curr_b)
    user_warr = []
    user_a_list = []
    user_b_list = []
    for i in range(attrNum):
        curr_a, curr_b, curr_warr = AttIssue(pp, apk_list[-1], ask_list[-1], upk, attrList[i], a_list[i][-1], b_list[i][-1], warr_list[i][-1])
        user_warr.append(curr_warr)
        # print(type(curr_warr[0]))
        # print(len(curr_warr))
        user_a_list.append(curr_a)
        user_b_list.append(curr_b)
    
    return pp, msk, user_warr, user_a_list, user_b_list, attrList, upk, usk, apk_list, ask_list
            
    

if __name__ == '__main__':
    attrNum = 10
    depth = 3 # the depth of authorities
    pp, msk, user_warr, user_a_list, user_b_list, attrSet, upk, usk, apk_list, ask_list = SystemSetup(attrNum=attrNum, depth=depth)
    # ***************************************************
    # r, s = msk
    # G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs = pp
    # group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    # mr, ms, nr, ns, alpha, beta, gamma, delta = tk
    # group: PairingGroup

    # a = a0 * prod(user_a_list)
    # testa = a0 ** group.init(ZR, attrNum + 1)
    # for i in range(attrNum):
    #     for n in range(depth):
    #         testa *= (h2 ** t1_list[i][n] * h5 ** t2_list[i][n]) ** (-ask_list[n][0])
    #         if n < depth - 1:
    #             testa *= (h2 ** ask_list[n + 1][0] * h5 ** ask_list[n + 1][1] * h1 ** attrSet[i]) ** (-t1_list[i][n])
    #         else:
    #             testa *= (h2 ** usk[0] * h5 ** usk[1] * h1 ** attrSet[i]) ** (-t1_list[i][n])
    # print(f'user_a_list[0] == testa: {user_a_list[0] == testa}')
    # print(f'a == testa: {a == testa}')
    # print(f1 ** t1_list[0][-1] == user_warr[0][-1][1])
    # for i in range(attrNum):
    #     for n in range(depth):
    #         pass
    #         # print(pair((h2 ** t1_list[i][n] * h5 ** t2_list[i][n]) ** (ask_list[n][0]), gr) == pair(apk_list[n][0]**mr, user_warr[i][n][1] * user_warr[i][n][2]))
    #         print(pair((h5 ** t1_list[i][n] * h4 ** t2_list[i][n]) ** (ask_list[n][1]), gs) == pair(apk_list[n][1]**ms, user_warr[i][n][1] * user_warr[i][n][2]))
            
    # b = b0 * prod(user_b_list)
    # testb = b0 ** group.init(ZR, attrNum + 1)
    # for i in range(attrNum):
    #     for n in range(depth):
    #         testb *= (h5 ** t1_list[i][n] * h4 ** t2_list[i][n]) ** (-ask_list[n][1])
    #         if n < depth - 1:
    #             testb *= (h5 ** ask_list[n + 1][0] * h4 ** ask_list[n + 1][1] * h3 ** attrSet[i]) ** (-t2_list[i][n])
    #         else:
    #             testb *= (h5 ** usk[0] * h4 ** usk[1] * h3 ** attrSet[i]) ** (-t2_list[i][n])
    # print(f'b == testb: {b == testb}')
    # eq1_left = (pair(a0, gr) * pair(b0, gs)) ** (group.init(ZR, attrNum + 1))
    # eq1_left = (pair(a0, gr)) ** (group.init(ZR, attrNum + 1))
    # eq1_left = (pair(b0, gs)) ** (group.init(ZR, attrNum + 1))
    # eq1_right = pair(a, gr) * pair(b, gs)
    # eq1_right = pair(testa, gr)
    # eq1_right = pair(testb, gs)
    # for i in range(attrNum):
    #     for n in range(depth):
    #         eq1_right *= pair(apk_list[n][0]**mr * apk_list[n][1]**ms, (user_warr[i][n][1] * user_warr[i][n][2]))
    #         # eq1_right *= pair(apk_list[n][0]**mr, (user_warr[i][n][1] * user_warr[i][n][2]))
    #         # eq1_right *= pair(apk_list[n][1]**ms, (user_warr[i][n][1] * user_warr[i][n][2]))
    #         if n < depth - 1:
    #             eq1_right *= pair(apk_list[n + 1][0] * apk_list[n + 1][1] * (g1 ** attrSet[i]), (user_warr[i][n][1]**mr) * (user_warr[i][n][2]**ms))
    #         else:
    #             eq1_right *= pair(upk[0] * upk[1] * (g1 ** attrSet[i]), (user_warr[i][n][1]**mr) * (user_warr[i][n][2]**ms))
    # print(f'eq1_left == eq1_right: {eq1_left == eq1_right}')