def flatten(input_structure):
    result = []
    # 遍历当前层级的每一个元素
    for item in input_structure:
        if isinstance(item, (list, tuple)):
            result.extend(flatten(item))
        else:
            result.append(item)
    return result


data = [11, (12, 34, ["a", "b"]), [11]]
output = flatten(data)
print(output)  