from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair
from Setup import Setup, KGen, AttIssue, SystemSetup
from TBE import TBE_Enc
from policy_tool import generate_S, solve_integer_z, generate_zS_proof, verify_zS_proof
from math import prod
import numpy as np
from Groth_Sahai import GS
import time
import pickle

def flatten(input_structure):
    result = []
    # 遍历当前层级的每一个元素
    for item in input_structure:
        if isinstance(item, (list, tuple)):
            result.extend(flatten(item))
        else:
            result.append(item)
    return result


def Sign(pp, upk, usk, apk_list, m, S, attrSet, user_a_list, user_b_list, user_warr):
    G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1 = pp
    group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    mr, ms, nr, ns, alpha, beta, gamma, delta = tk

    group: PairingGroup
    GS_1: GS

    k1, k2, k3 = group.random(ZR, 3)
    otsvk = (g2_tilde ** k1, g2_tilde ** k2, k3)
    z = solve_integer_z(S)
    attrNum = len(user_warr)
    a = a0 * prod(user_a_list)
    b = b0 * prod(user_b_list)
    
    TBE_pp = (group, g1, g2)
    Cipher = TBE_Enc(TBE_pp, tpk, flatten((user_warr, upk, a, b)), group.hash(otsvk, ZR))


    # eq1_left = c ** (group.init(ZR, attrNum + 1))
    # eq1_right = pair(a, gr) * pair(b, gs)
    # for i in range(attrNum):
    #     for n in range(depth):
    #         eq1_right *= pair(apk_list[n][0]**mr * apk_list[n][1]**ms, (user_warr[i][n][1]) * (user_warr[i][n][2]))
    #         if n < depth - 1:
    #             eq1_right *= pair(apk_list[n + 1][0] * apk_list[n + 1][1] * (g1 ** attrSet[i]), (user_warr[i][n][1]**mr) * (user_warr[i][n][2]**ms))
    #         else:
    #             eq1_right *= pair(upk[0] * upk[1] * (g1 ** attrSet[i]), (user_warr[i][n][1]**mr) * (user_warr[i][n][2]**ms))
    # print(f'eq1_left == eq1_right: {eq1_left == eq1_right}')

    GS_pp={'G1':g1,'G2':g2,'GT':pair(g1,g2)}

    zS_pi_list = generate_zS_proof(z, S, GS_pp, crs, GS_1)
    # print(f'zs: {verify_zS_proof(GS_pp, crs, GS_1, zS_pi_list)}')

    eq1_len = 4 + depth * attrNum * 2
    eq1_c_a = [None for _ in range(eq1_len)]
    eq1_c_b = eq1_c_a[:]
    eq1_gammaT = np.eye(eq1_len, dtype=int).tolist()
    eq1_gammaT[0][0] = -1; eq1_gammaT[1][1] = -1
    eq1_x = [a0 ** group.init(ZR, attrNum + 1), b0 ** group.init(ZR, attrNum + 1), a, b]
    eq1_y = [gr, gs, gr, gs]
    for i in range(attrNum):
        for n in range(depth):
            eq1_x.append(apk_list[n][0]**mr * apk_list[n][1]**ms)
            eq1_y.append((user_warr[i][n][1]) * (user_warr[i][n][2]))
            if n < depth - 1:
                eq1_x.append(apk_list[n + 1][0] * apk_list[n + 1][1] * (g1 ** attrSet[i]))
                eq1_y.append((user_warr[i][n][1]**mr) * (user_warr[i][n][2]**ms))
            else:
                eq1_x.append(upk[0] * upk[1] * (g1 ** attrSet[i]))
                eq1_y.append((user_warr[i][n][1]**mr) * (user_warr[i][n][2]**ms))
    eq1_com_x, eq1_com_y, eq1_r, eq1_s = GS_1.commit(crs, eq1_x, eq1_y, eq1_c_a, eq1_c_b)
    eq1_pi = GS_1.prove(crs, eq1_x, eq1_y, eq1_r, eq1_s, eq1_com_y, [eq1_gammaT])
    eq1_pi_list = (eq1_pi, eq1_com_x, eq1_com_y, [eq1_gammaT])
    # print(GS_1.Batched_verify(GS_pp, crs, eq1_pi, eq1_com_x, eq1_com_y, [eq1_gammaT]))


    # eq2_left = d ** (group.init(ZR, attrNum + 1))
    # eq2_right = pair(a, hr) * pair(b, hs)
    # for i in range(attrNum):
    #     for n in range(depth):
    #         eq2_right *= pair(apk_list[n][0]**nr * apk_list[n][1]**ns, (user_warr[i][n][1]) * (user_warr[i][n][2]))
    #         if n < depth - 1:
    #             eq2_right *= pair(apk_list[n + 1][0] * apk_list[n + 1][1] * (g1 ** attrSet[i]), (user_warr[i][n][1]**nr) * (user_warr[i][n][2]**ns))
    #         else:
    #             eq2_right *= pair(upk[0] * upk[1] * (g1 ** attrSet[i]), (user_warr[i][n][1]**nr) * (user_warr[i][n][2]**ns))
    # print(f'eq1_left == eq2_right: {eq2_left == eq2_right}')

    eq2_len = 4 + depth * attrNum * 2
    eq2_c_a = [None for _ in range(eq2_len)]
    eq2_c_b = eq2_c_a[:]
    eq2_gammaT = np.eye(eq2_len, dtype=int).tolist()
    eq2_gammaT[0][0] = -1; eq2_gammaT[1][1] = -1
    eq2_x = [a0 ** group.init(ZR, attrNum + 1), b0 ** group.init(ZR, attrNum + 1), a, b]
    eq2_y = [hr, hs, hr, hs]
    for i in range(attrNum):
        for n in range(depth):
            eq2_x.append(apk_list[n][0]**nr * apk_list[n][1]**ns)
            eq2_y.append((user_warr[i][n][1]) * (user_warr[i][n][2]))
            if n < depth - 1:
                eq2_x.append(apk_list[n + 1][0] * apk_list[n + 1][1] * (g1 ** attrSet[i]))
                eq2_y.append((user_warr[i][n][1]**nr) * (user_warr[i][n][2]**ns))
            else:
                eq2_x.append(upk[0] * upk[1] * (g1 ** attrSet[i]))
                eq2_y.append((user_warr[i][n][1]**nr) * (user_warr[i][n][2]**ns))
    eq2_com_x, eq2_com_y, eq2_r, eq2_s = GS_1.commit(crs, eq2_x, eq2_y, eq2_c_a, eq2_c_b)
    eq2_pi = GS_1.prove(crs, eq2_x, eq2_y, eq2_r, eq2_s, eq2_com_y, [eq2_gammaT])
    # print(GS_1.Batched_verify(GS_pp, crs, eq2_pi, eq2_com_x, eq2_com_y, [eq2_gammaT]))
    eq2_pi_list = (eq2_pi, eq2_com_x, eq2_com_y, [eq2_gammaT])

    eq3_right_input1 = group.init(G2, 1)
    eq3_right_input2 = group.init(G2, 1)
    eq3_right_input3 = group.init(G2, 1)
    for i in range(attrNum):
        for n in range(depth):
            # print(pair(g1, user_warr[i][n][1] * user_warr[i][n][2]) == pair(h1, user_warr[i][n][4]) * pair(h3, user_warr[i][n][3]))
            eq3_right_input1 *= user_warr[i][n][1] * user_warr[i][n][2]
            eq3_right_input2 *= user_warr[i][n][4]
            eq3_right_input3 *= user_warr[i][n][3]
    # print(f'eq3: {pair(g1, eq3_right_input1) == pair(h3, eq3_right_input2) * pair(h1, eq3_right_input3)}')

    eq3_c_a = [None for _ in range(3)]
    eq3_c_b = eq3_c_a[:]
    eq3_gammaT = np.eye(3, dtype=int).tolist()
    eq3_gammaT[0][0] = -1
    eq3_x = [g1, h3, h1]
    eq3_y = [eq3_right_input1, eq3_right_input2, eq3_right_input3]
    eq3_com_x, eq3_com_y, eq3_r, eq3_s = GS_1.commit(crs, eq3_x, eq3_y, eq3_c_a, eq3_c_b)
    eq3_pi = GS_1.prove(crs, eq3_x, eq3_y, eq3_r, eq3_s, eq3_com_y, [eq3_gammaT])
    # print(GS_1.Batched_verify(GS_pp, crs, eq3_pi, eq3_com_x, eq3_com_y, [eq3_gammaT]))
    eq3_pi_list = (eq3_pi, eq3_com_x, eq3_com_y, [eq3_gammaT])

    H = group.hash((zS_pi_list, eq1_pi, eq2_pi, eq3_pi, Cipher, S, m, otsvk), ZR)
    sigma_0 = g1_tilde ** (group.init(ZR, 1) / (k1 + H + k2 * k3))
    # print(pair(sigma_0, g2_tilde ** k1 * g2_tilde ** H * g2_tilde ** (k2 * k3)) == zeta)

    return sigma_0, Cipher, zS_pi_list, eq1_pi_list, eq2_pi_list, eq3_pi_list, otsvk

def Verify(pp, sigma, m, S):
    G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1 = pp
    group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    mr, ms, nr, ns, alpha, beta, gamma, delta = tk

    group: PairingGroup
    GS_1: GS
    GS_pp={'G1':g1,'G2':g2,'GT':pair(g1,g2)}

    sigma_0, Cipher, zS_pi_list, eq1_pi_list, eq2_pi_list, eq3_pi_list, otsvk = sigma

    if not verify_zS_proof(GS_pp, crs, GS_1, zS_pi_list):
        return False
    
    eq1_pi, eq1_com_x, eq1_com_y, [eq1_gammaT] = eq1_pi_list
    if not GS_1.Batched_verify(GS_pp, crs, eq1_pi, eq1_com_x, eq1_com_y, [eq1_gammaT]):
        return False

    eq2_pi, eq2_com_x, eq2_com_y, [eq2_gammaT] = eq2_pi_list
    if not GS_1.Batched_verify(GS_pp, crs, eq2_pi, eq2_com_x, eq2_com_y, [eq2_gammaT]):
        return False

    eq3_pi, eq3_com_x, eq3_com_y, [eq3_gammaT] = eq3_pi_list
    if not GS_1.Batched_verify(GS_pp, crs, eq3_pi, eq3_com_x, eq3_com_y, [eq3_gammaT]):
        return False
    
    H = group.hash((zS_pi_list, eq1_pi, eq2_pi, eq3_pi, Cipher, S, m, otsvk), ZR)
    if pair(sigma_0, otsvk[0] * g2_tilde ** H * otsvk[1] ** otsvk[2]) != zeta:
        return False 
    
    return True
    

if __name__ == '__main__':
    attrNum = 50
    depth = 3
    pp, msk, user_warr, user_a_list, user_b_list, attrSet, upk, usk, apk_list, ask_list = SystemSetup(attrNum=attrNum, depth=depth)

    G_mathcal, c, d, a0, b0, gr, gs, hr, hs, tk, zeta, g1_tilde, g2_tilde, tpk, crs, GS_1 = pp
    group, g1, g2, h1, h2, h3, h4, h5, f1, f2 = G_mathcal
    mr, ms, nr, ns, alpha, beta, gamma, delta = tk
    group: PairingGroup

    m = "hello world"
    S = generate_S(attrNum)
    
    time1 = time.time()
    sigma = Sign(pp, upk, usk, apk_list, m, S, attrSet, user_a_list, user_b_list, user_warr)
    time2 = time.time()
    sign_time = time2 - time1
    print(f'first sign time: {sign_time}')

    time3 = time.time()
    result = Verify(pp, sigma, m, S)
    time4 = time.time()
    verify_time = time4 - time3
    print(f'first verify time: {verify_time}')