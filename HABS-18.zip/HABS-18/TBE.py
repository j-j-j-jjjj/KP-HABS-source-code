from charm.toolbox.pairinggroup import PairingGroup,ZR,G1,G2,GT,pair

def TBE_Setup(secParam: int):
    group = PairingGroup("BN254", secparam = secParam)
    g1, g2 = (group.random(G1), group.random(G2))
    return (group, g1, g2)

def TBE_KGen(TBE_pp):
    group, g1, g2 = TBE_pp
    eta1, eta2 = group.random(ZR, 2)
    V1 = g1 ** eta1
    V2 = g1 ** eta2
    V3, V4 = group.random(G2, 2)
    sk = (eta1, eta2)
    pk = (V1, V2, V3, V4)
    return pk, sk

def TBE_Enc(TBE_pp, pk, M, t):
    group, g1, g2 = TBE_pp
    group: PairingGroup
    V1, V2, V3, V4 = pk
    r, s = group.random(ZR, 2)
    Y1 = V1 ** r
    Y2 = V2 ** s
    M = group.hash(M, G1)
    Y3 = (g1 ** (r + s)) * M
    Y4 = ((g2 ** t) * V3) ** r
    Y5 = ((g2 ** t) * V4) ** s
    return (Y1, Y2, Y3, Y4, Y5)

def TBE_Verify(TBE_pp, pk, Cipher, t):
    group, g1, g2 = TBE_pp
    V1, V2, V3, V4 = pk
    Y1, Y2, Y3, Y4, Y5 = Cipher
    return pair(Y1, (g2 ** t) * V3) == pair(V1, Y4) and pair(Y2, (g2 ** t) * V4) == pair(V2, Y5)

def TBE_Dec(TBE_pp, pk, sk, Cipher, t):
    if not TBE_Verify(TBE_pp, pk, Cipher, t):
        print('invalid Cipher in TBE')
        return None
    eta1, eta2 = sk
    Y1, Y2, Y3, Y4, Y5 = Cipher
    return Y3 * (Y1 ** (-1 * (eta1 ** -1))) * (Y2 ** (-1 * (eta2 ** -1)))

def Unbound_TBE_Enc(TBE_pp, pk, M_list, t):
    Cipher_list = []
    for M in M_list:
        Cipher_list.append(TBE_Enc(TBE_pp, pk, M, t))
    return Cipher_list

def Unbound_TBE_Dec(TBE_pp, pk, sk, Cipher_list, t):
    M_list = []
    for Cipher in Cipher_list:
        M_list.append(TBE_Dec(TBE_pp, pk, sk, Cipher, t))
    return M_list

def Unbound_TBE_Verify(TBE_pp, pk, Cipher_list, t):
    for Cipher in Cipher_list:
        if not TBE_Verify(TBE_pp, pk, Cipher, t):
            return False
    return True

if __name__ == '__main__':
    TBE_pp = TBE_Setup(512)
    group, g1, g2 = TBE_pp
    pk, sk = TBE_KGen(TBE_pp)
    M = group.random(G1)
    t = group.random(ZR)
    Cipher = TBE_Enc(TBE_pp, pk, M, t)
    dec_M = TBE_Dec(TBE_pp, pk, sk, Cipher, t)
    print(f'correctness of TBE_DEC: {dec_M == M}')

    M_list = list(group.random(G1, 100))
    C_list = Unbound_TBE_Enc(TBE_pp, pk, M_list, t)
    print('end enc')
    dec_M_list = Unbound_TBE_Dec(TBE_pp, pk, sk, C_list, t)
    for i in range(len(M_list)):
        if M_list[i] != dec_M_list[i]:
            print("False")
            break